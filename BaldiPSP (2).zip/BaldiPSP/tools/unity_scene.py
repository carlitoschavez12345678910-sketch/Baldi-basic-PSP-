"""Lector minimo de escenas YAML de Unity (suficiente para Baldi's Basics)."""
import re, glob, os, math, yaml
try:
    Loader = yaml.CSafeLoader
except AttributeError:
    Loader = yaml.SafeLoader

def load_guid_map(root):
    g2p = {}
    for m in glob.glob(os.path.join(root, 'Assets/**/*.meta'), recursive=True):
        s = open(m, encoding='utf-8-sig', errors='ignore').read()
        mm = re.search(r'guid: ([0-9a-f]{32})', s)
        if mm:
            g2p[mm.group(1)] = m[:-5]
    return g2p

def load_scene(path):
    t = open(path, encoding='utf-8-sig').read()
    parts = re.split(r'^--- !u!(\d+) &(-?\d+)(?: stripped)?[ \t]*$', t, flags=re.M)
    objs = {}
    for i in range(1, len(parts), 3):
        cls, fid, body = int(parts[i]), int(parts[i+1]), parts[i+2]
        try:
            d = yaml.load(body, Loader=Loader)
        except Exception:
            continue
        if not d: continue
        (k, v), = d.items()
        objs[fid] = (cls, k, v)
    return objs

# ---- matematicas 4x4 (column-vector, row-major lists) ----
def quat_to_mat(q):
    x, y, z, w = q
    return [[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
            [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
            [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]]

def trs(pos, rot, scl):
    R = quat_to_mat(rot)
    M = [[R[r][c]*scl[c] for c in range(3)] + [pos[r]] for r in range(3)]
    M.append([0, 0, 0, 1])
    return M

def mmul(A, B):
    return [[sum(A[i][k]*B[k][j] for k in range(4)) for j in range(4)] for i in range(4)]

def xform(M, p):
    return [M[i][0]*p[0]+M[i][1]*p[1]+M[i][2]*p[2]+M[i][3] for i in range(3)]

def v3(d): return [d['x'], d['y'], d['z']]
def q4(d): return [d['x'], d['y'], d['z'], d['w']]

class Scene:
    def __init__(self, path):
        self.objs = load_scene(path)
        self.go = {f: v for f, (c, k, v) in self.objs.items() if c == 1}
        self.tf = {f: v for f, (c, k, v) in self.objs.items() if c == 4}
        self._world = {}
        self.comp_by_go = {}
        for f, (c, k, v) in self.objs.items():
            g = v.get('m_GameObject', {}).get('fileID') if isinstance(v, dict) else None
            if g: self.comp_by_go.setdefault(g, []).append((f, c, k, v))
        self.go_tf = {}
        for g, comps in self.comp_by_go.items():
            for f, c, k, v in comps:
                if c in (4, 224): self.go_tf[g] = f
    def world(self, tfid):
        if tfid in self._world: return self._world[tfid]
        t = self.tf.get(tfid)
        if t is None:
            t = self.objs[tfid][2]
        loc = trs(v3(t['m_LocalPosition']), q4(t['m_LocalRotation']), v3(t['m_LocalScale'])) if 'm_LocalScale' in t else [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]
        par = t.get('m_Father', {}).get('fileID', 0)
        M = mmul(self.world(par), loc) if par else loc
        self._world[tfid] = M
        return M
    def active(self, g):
        """Activo en jerarquia."""
        ok = True
        tf = self.go_tf.get(g)
        seen = 0
        while g and seen < 64:
            seen += 1
            go = self.go.get(g)
            if go is None: break
            if not go.get('m_IsActive', 1): return False
            tf = self.go_tf.get(g)
            par = self.tf[tf]['m_Father']['fileID'] if tf in self.tf else 0
            g = self.tf[par]['m_GameObject']['fileID'] if par in self.tf else 0
        return True
    def name(self, g): return self.go[g].get('m_Name', '')
    def tag(self, g): return self.go[g].get('m_TagString', '')
    def path(self, g):
        out = []
        while g:
            out.append(self.name(g))
            tf = self.go_tf.get(g)
            par = self.tf[tf]['m_Father']['fileID'] if tf in self.tf else 0
            g = self.tf[par]['m_GameObject']['fileID'] if par in self.tf else 0
        return '/'.join(reversed(out))
