/* Pruebas en PC del nucleo del juego (sin graficos). Compilar con Makefile.host */
#include "game.h"
#include "sound_ids.h"
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { printf("  FALLO: "); printf(__VA_ARGS__); printf("\n"); fails++; } else { printf("  ok: "); printf(__VA_ARGS__); printf("\n"); } } while (0)

static Level lv; static SoundPack sp; static Game G;

static bool inside_wall(const Game *g, float x, float z, float r) {
    for (int i = 0; i < g->lv->nSegs; i++) {
        const LvSeg *s = &g->lv->segs[i]; if (!game_door_blocks(g, s)) continue;
        float dx = s->x2 - s->x1, dz = s->z2 - s->z1, L2 = dx * dx + dz * dz;
        float t = L2 > 0 ? ((x - s->x1) * dx + (z - s->z1) * dz) / L2 : 0; t = t < 0 ? 0 : (t > 1 ? 1 : t);
        float cx = s->x1 + t * dx, cz = s->z1 + t * dz;
        if ((x - cx) * (x - cx) + (z - cz) * (z - cz) < (r - 0.05f) * (r - 0.05f)) return true;
    }
    return false;
}
static void place_facing(Game *g, float tx, float tz) {   /* busca un punto libre con vista al cuaderno */
    for (int dist = 4; dist <= 9; dist++) for (int a = 0; a < 16; a++) {
        float ang = a * 3.14159f / 8, px = tx + dist * cosf(ang), pz = tz + dist * sinf(ang);
        if (inside_wall(g, px, pz, 2.2f)) continue;
        g->x = px; g->z = pz; g->yaw = atan2f(tx - px, tz - pz);
        char nm[48]; if (game_target_name(g, nm, sizeof nm) && !strcmp(nm, "Notebook")) return;
    }
    printf("  (!) place_facing no encontro posicion\n");
}
static void step(Game *g, Input *in, float dt, int n) { for (int i = 0; i < n; i++) { game_update(g, in, dt); in->pressed = 0; } }

int main(int argc, char **argv) {
    const char *dir = argc > 1 ? argv[1] : "build_data";
    char p[512];
    snprintf(p, sizeof p, "%s/level.bin", dir); if (!level_load(&lv, p)) { printf("no level\n"); return 1; }
    snprintf(p, sizeof p, "%s/textures.bin", dir); if (!texpack_load(&lv.tex, p)) { printf("no tex\n"); return 1; }
    snprintf(p, sizeof p, "%s/sounds.bin", dir); if (!soundpack_load(&sp, p)) { printf("no snd\n"); return 1; }
    printf("nivel: %d quads, %d dquads, %d segs, %d grupos, %d pickups, %d cuadernos, %d waypoints, nav %dx%d\n",
           lv.nQuads, lv.nDQuads, lv.nSegs, lv.nGroups, lv.nPickups, lv.nNotebooks, lv.nWaypoints, lv.navW, lv.navH);
    CHECK(sp.count == SOUND_COUNT, "sonidos en pack (%d) == SOUND_COUNT (%d)", sp.count, SOUND_COUNT);
    CHECK(lv.tex.count == lv.nTex, "texturas en pack (%d) == referenciadas (%d)", lv.tex.count, lv.nTex);
    for (int i = 0; i < lv.nQuads; i++) if (lv.quads[i].tex != 0xFFFF && lv.quads[i].tex >= lv.nTex) { CHECK(0, "quad con textura fuera de rango"); break; }
    memset(&G, 0, sizeof G);
    for (int i = 0; i < SOUND_COUNT && i < 64; i++) G.sndLen[i] = (float)sp.n[i] / sp.rate;
    game_init(&G, &lv, 12345);
    Input in; memset(&in, 0, sizeof in);

    printf("\n[1] Colisiones del jugador\n");
    CHECK(!inside_wall(&G, G.x, G.z, 2.0f), "spawn (%.1f,%.1f) libre de paredes", G.x, G.z);
    int bad = 0; float minx = 1e9, maxx = -1e9, minz = 1e9, maxz = -1e9;
    in.fwd = 1; in.held = BTN_RUN;
    for (int k = 0; k < 40; k++) {                    /* 40 recorridos aleatorios de 20 s corriendo contra paredes */
        G.stamina = 100; G.yaw = (k * 37 % 360) * 3.14159f / 180; in.turn = (k % 5 - 2) * 0.12f;
        for (int i = 0; i < 1200; i++) {
            game_update(&G, &in, 1.0f / 60); in.pressed = 0;
            if (inside_wall(&G, G.x, G.z, 2.0f)) bad++;
            if (G.x < minx) minx = G.x;
            if (G.x > maxx) maxx = G.x;
            if (G.z < minz) minz = G.z;
            if (G.z > maxz) maxz = G.z;
        }
    }
    CHECK(bad == 0, "jugador nunca penetra paredes (%d violaciones en 48000 pasos)", bad);
    CHECK(minx > -175 && maxx < 140 && minz > -20 && maxz < 375, "jugador dentro del mapa: x[%.0f,%.0f] z[%.0f,%.0f]", minx, maxx, minz, maxz);

    printf("\n[2] Navegacion A*\n");
    int ok = 0, tot = 0; float px[MAX_PATH], pz[MAX_PATH]; int n;
    clock_t c0 = clock();
    for (int a = 0; a < 29; a++) for (int b = 0; b < 29; b += 7) { if (a == b) continue; tot++;
        if (nav_find_path(&lv, lv.waypoints[a].x, lv.waypoints[a].z, lv.waypoints[b].x, lv.waypoints[b].z, px, pz, MAX_PATH, &n) && n > 0) ok++; }
    double ms = 1000.0 * (clock() - c0) / CLOCKS_PER_SEC / tot;
    CHECK(ok == tot, "ruta entre waypoints: %d/%d encontradas (%.2f ms/ruta en PC)", ok, tot, ms);
    nav_find_path(&lv, lv.waypoints[0].x, lv.waypoints[0].z, lv.waypoints[20].x, lv.waypoints[20].z, px, pz, MAX_PATH, &n);
    printf("  ruta ejemplo wp0 -> wp20: %d puntos\n", n);

    printf("\n[3] Cuaderno + minijuego de mates\n");
    game_init(&G, &lv, 777); memset(&in, 0, sizeof in);
    place_facing(&G, lv.notebooks[0].x, lv.notebooks[0].z);
    step(&G, &in, 1.0f / 60, 2);
    char tn[48]; bool t = game_target_name(&G, tn, sizeof tn); CHECK(t, "cuaderno detectado como objetivo (\"%s\")", t ? tn : "-");
    in.pressed = BTN_INTERACT; step(&G, &in, 1.0f / 60, 1);
    CHECK(G.mg.active && G.notebooks == 1, "minijuego activo, notebooks=%d", G.notebooks);
    for (int pr = 0; pr < 3; pr++) {          /* respuestas correctas */
        int a, b; char op; sscanf(G.mg.q + 3, "%d %c %d", &a, &op, &b);
        int sol = op == '+' ? a + b : a - b; char buf[16]; snprintf(buf, sizeof buf, "%d", sol);
        in.pressed = BTN_RIGHT; step(&G, &in, 1.0f / 60, 1);                /* borrar y escribir digitos */
        while (G.mg.alen) { in.pressed = BTN_LEFT; step(&G, &in, 1.0f / 60, 1); }
        for (char *c = buf; *c; c++) {
            if (*c == '-') { in.pressed = BTN_MINUS; step(&G, &in, 1.0f / 60, 1); continue; }
            in.pressed = BTN_RIGHT; step(&G, &in, 1.0f / 60, 1);
            for (int k = 0; k < *c - '0'; k++) { in.pressed = BTN_UP; step(&G, &in, 1.0f / 60, 1); }
        }
        in.pressed = BTN_INTERACT; step(&G, &in, 1.0f / 60, 1);
    }
    CHECK(G.mg.problem > 3 && G.mg.res[0] == 1 && G.mg.res[1] == 1 && G.mg.res[2] == 1, "3 respuestas correctas aceptadas, sin spoop (%d)", G.spoop);
    step(&G, &in, 1.0f / 60, 400);
    CHECK(!G.mg.active, "minijuego termina tras 5 s");
    int quarterOn = 0; for (int i = 0; i < lv.nPickups; i++) if (lv.pickups[i].type == 5 && !lv.pickups[i].active && G.pickupOn[i]) quarterOn = 1;
    CHECK(quarterOn, "recompensa: moneda aparece tras el primer cuaderno");

    printf("\n[4] Respuesta incorrecta -> spoop mode + Baldi\n");
    game_init(&G, &lv, 99); memset(&in, 0, sizeof in);
    place_facing(&G, lv.notebooks[1].x, lv.notebooks[1].z);
    in.pressed = BTN_INTERACT; step(&G, &in, 1.0f / 60, 1);
    CHECK(G.mg.active, "segundo cuaderno abre el minijuego");
    in.pressed = BTN_RIGHT; step(&G, &in, 1.0f / 60, 1);
    in.pressed = BTN_UP; step(&G, &in, 1.0f / 60, 1); in.pressed = BTN_UP; step(&G, &in, 1.0f / 60, 1);
    in.pressed = BTN_INTERACT; step(&G, &in, 1.0f / 60, 1);
    CHECK(G.spoop && G.npc[NPC_BALDI].active, "una respuesta incorrecta activa a Baldi (spoop)");

    printf("\n[5] Baldi persigue al jugador quieto\n");
    G.mg.active = false; G.freezeT = 0; memset(&in, 0, sizeof in);
    float bx0 = G.npc[NPC_BALDI].x, bz0 = G.npc[NPC_BALDI].z;
    float travelled = 0, lx = bx0, lz = bz0; int slaps = 0; float caughtAt = -1;
    for (int i = 0; i < 60 * 240 && G.state == ST_PLAYING; i++) {
        game_update(&G, &in, 1.0f / 60);
        for (int k = 0; k < G.nSnd; k++) if (G.snd[k] == SND_SLAP) slaps++;
        travelled += hypotf(G.npc[NPC_BALDI].x - lx, G.npc[NPC_BALDI].z - lz); lx = G.npc[NPC_BALDI].x; lz = G.npc[NPC_BALDI].z;
        if (G.state != ST_PLAYING) caughtAt = i / 60.0f;
    }
    CHECK(travelled > 100, "Baldi recorre distancia (%.0f u) y da %d ruletazos", travelled, slaps);
    CHECK(G.state == ST_GAMEOVER, "Baldi atrapa al jugador quieto (tras %.1f s)", caughtAt);

    printf("\n[6] Puertas\n");
    game_init(&G, &lv, 5); memset(&in, 0, sizeof in);
    int di = -1; for (int i = 0; i < lv.nGroups; i++) if (lv.groups[i].kind == GRP_DOOR) { di = i; break; }
    const LvGroup *dg = &lv.groups[di];
    G.x = dg->x + 4; G.z = dg->z; G.yaw = -90 * 3.14159f / 180;
    for (int a = 0; a < 4; a++) { G.x = dg->x + (a == 0 ? 4 : a == 1 ? -4 : 0); G.z = dg->z + (a == 2 ? 4 : a == 3 ? -4 : 0); G.yaw = atan2f(dg->x - G.x, dg->z - G.z);
        in.pressed = BTN_INTERACT; step(&G, &in, 1.0f / 60, 1); if (G.door[di].open) break; }
    CHECK(G.door[di].open, "interactuar abre la puerta %d en (%.0f,%.0f)", di, dg->x, dg->z);
    step(&G, &in, 1.0f / 60, 250);
    CHECK(!G.door[di].open, "la puerta se cierra sola a los 3 s");
    int sw = -1; for (int i = 0; i < lv.nGroups; i++) if (lv.groups[i].kind == GRP_SWING) { sw = i; break; }
    CHECK(G.door[sw].locked, "puerta de vaiven bloqueada con 0 cuadernos");
    G.notebooks = 2; step(&G, &in, 1.0f / 60, 2);
    CHECK(!G.door[sw].locked, "puerta de vaiven se desbloquea con 2 cuadernos");

    printf("\n[7] Final: 7 cuadernos y salida\n");
    game_init(&G, &lv, 3); memset(&in, 0, sizeof in);
    G.notebooks = 7; G.spoop = true; G.finale = true;
    for (int i = 0; i < lv.nTriggers; i++) if (lv.triggers[i].kind == TRG_EXIT) { G.x = (lv.triggers[i].x0 + lv.triggers[i].x1) / 2; G.z = (lv.triggers[i].z0 + lv.triggers[i].z1) / 2; break; }
    step(&G, &in, 1.0f / 60, 2);
    CHECK(G.state == ST_WON, "tocar la salida con 7 cuadernos gana (state=%d)", G.state);

    printf("\n[8] Rendimiento (todos los NPCs activos, 60 s simulados)\n");
    game_init(&G, &lv, 42); memset(&in, 0, sizeof in); G.spoop = false; G.notebooks = 3; G.guilt = 0;
    G.x = 5; G.z = 60;
    G.spoop = false; { /* activar */ in.pressed = 0; }
    extern void game_force_spoop(Game *g);
    c0 = clock(); int frames = 0; in.fwd = 0.5f; in.turn = 0.2f;
    game_force_spoop(&G);
    for (int i = 0; i < 3600 && G.state == ST_PLAYING; i++) { game_update(&G, &in, 1.0f / 60); frames++; if (G.mg.active) G.mg.active = false; }
    double per = 1000.0 * (clock() - c0) / CLOCKS_PER_SEC / (frames ? frames : 1);
    printf("  %d fotogramas, %.3f ms/fotograma de logica en este PC (PSP ~ 40-60x mas lenta si el PC es rapido)\n", frames, per);
    CHECK(per < 1.0, "logica < 1 ms/fotograma en PC");

    printf("\n%s (%d fallos)\n", fails ? "HAY FALLOS" : "TODO OK", fails);
    return fails ? 1 : 0;
}
