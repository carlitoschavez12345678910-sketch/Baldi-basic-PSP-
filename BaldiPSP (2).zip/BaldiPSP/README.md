# Baldi's Basics Classic 1.4.3 → PSP

Port a PSP hecho a partir del decompile de Unity (`baldi_s_basics_classic_143_decompile_v5.zip`).
El nivel (`School.unity`) se convierte con scripts de Python y el juego se reescribe en C con el PSPSDK.

## Estado: qué está verificado y qué no
- **Verificado aquí (PC):** exportador de nivel, conversión de texturas/audio y todo el núcleo del juego
  (`game.c`, `level.c`): `make -f Makefile.host && ./host_test data` → todas las pruebas OK
  (colisiones, A*, cuadernos, mates, Baldi, puertas, final, rendimiento).
  La geometría exportada se comprobó con un render de prueba (`docs/vista_pasillo.png`).
- **NO probado:** `render_psp.c`, `audio_psp.c`, `main_psp.c`. Solo pasaron una comprobación de sintaxis contra
  cabeceras simuladas y un test numérico de la matriz de cámara. **Nunca se compilaron con el PSPSDK real ni se
  ejecutaron en PPSSPP/consola**, así que puede haber errores de compilación o de renderizado que corregir.

## Compilar
1. Instala PSPDEV (https://pspdev.github.io/) y comprueba que `psp-config --pspsdk-path` funciona.
2. `make` → genera `EBOOT.PBP`.
3. Crea `ms0:/PSP/GAME/BaldiPSP/` y copia `EBOOT.PBP` **y la carpeta `data/`** (o abre `EBOOT.PBP` en PPSSPP con `data/` al lado).

`data/` ya viene generada. Para regenerarla desde tu proyecto Unity (Python 3, Pillow, numpy, PyYAML, ffmpeg):
`make data PROJ=/ruta/al/proyecto_unity` (la carpeta que contiene `Assets/`).

## Controles
| PSP | Acción |
|---|---|
| Analógico | Avanzar/retroceder y girar |
| L / R | Desplazamiento lateral |
| Círculo (mantener) | Correr (gasta estamina) |
| Cruz | Abrir puertas, coger objetos y cuadernos, aceptar respuesta |
| Cuadrado | Usar el objeto seleccionado |
| D-pad ←/→ | Cambiar de objeto |
| Start | Pausa |
| Minijuego de mates | D-pad ↑/↓ cambia el dígito, → añade dígito, ← borra, Triángulo ±, Cruz acepta |

## Qué incluye
Colegio completo (2347 quads + 242 de puertas/entradas, 2701 segmentos de colisión), 7 cuadernos, 16 ítems con sus
11 efectos, puertas normales y de vaivén, minijuego de mates con voz de Baldi, Baldi con la IA original
(enfado, oído, ruletazos), Director (castigo), Playtime, 1st Prize, Gotta Sweep, Bully, Arts & Crafters,
modo final con salidas falsas, victoria y pantalla de derrota.

## Simplificaciones respecto al original
- Solo modo historia (sin modo infinito, opciones ni Baldi tutor inicial).
- Sin NavMesh: A* sobre una rejilla de 2,5 u exportada del suelo.
- Escritorios y sillas son cajas simples; sin iluminación ni animaciones de sprites.
- Jump rope de Playtime reducido a "inmovilizado 6 s" (las tijeras lo cancelan).
- Sin ambiente de fondo, música de Playtime ni efectos sonoros del final.
- Texturas a 16 bits y máx. 128 px; audio mono 22 kHz.

## Estructura
`src/game.c` lógica · `src/level.c` carga + A* · `src/render_psp.c` GU · `src/audio_psp.c` mezclador ·
`src/main_psp.c` bucle/entrada · `tools/` exportadores · `data/` assets convertidos.

## Compilar sin instalar nada (GitHub)
1. Crea un repositorio nuevo en github.com y sube **todo el contenido** de esta carpeta (incluida `.github` y `data`).
2. Ve a la pestaña **Actions** → "Compilar EBOOT para PSP" → espera a que termine (unos minutos).
3. Entra a la ejecución y descarga el artefacto **BaldiPSP**: trae `EBOOT.PBP` y `data/`.
4. Copia esa carpeta a `ms0:/PSP/GAME/BaldiPSP/` o abre `EBOOT.PBP` en PPSSPP.
Si la compilación falla, abre el log rojo y pásame el error.
