#!/usr/bin/env python3
"""
Convierte sprites, fuente de texto y audio a formatos aptos para la PSP.

Uso: python3 convert_assets.py <proyecto_unity> <dir_salida>

Genera:
  sprites.bin   (mismo formato BTEX que textures.bin) + sprite_ids.h
  sounds.bin    PCM 16 bit mono 22050 Hz + sound_ids.h
"""
import sys, os, glob, struct, subprocess, re
import numpy as np
from PIL import Image, ImageDraw, ImageFont

RATE = 22050

def near_p2(n, cap):
    r = 8
    while r * 2 <= n * 1.4 and r < cap: r *= 2
    return min(r, cap)

def find(proj, name):
    hits = glob.glob(os.path.join(proj, 'Assets/**', name), recursive=True)
    hits = [h for h in hits if not h.endswith('.meta')]
    if not hits: raise FileNotFoundError(name)
    return sorted(hits)[0]

def to_psp(im, cap=128, tw=None, th=None):
    im = im.convert('RGBA')
    w, h = im.size
    if tw is None:
        s = min(1.0, cap / max(w, h))
        tw, th = near_p2(w * s, cap), near_p2(h * s, cap)
    # sprites: bordes transparentes sin "halo" blanco (premultiplicar color de fondo)
    arr = np.array(im)
    im2 = im.resize((tw, th), Image.LANCZOS)
    arr = np.array(im2).astype(np.uint32)
    r, g, b, a = arr[..., 0], arr[..., 1], arr[..., 2], arr[..., 3]
    a_bin = (a >= 128).astype(np.uint32)
    px = (r >> 3) | ((g >> 3) << 5) | ((b >> 3) << 10) | (a_bin << 15)       # 5551
    return tw, th, 1, px.astype('<u2').tobytes()

def write_pack(path, items):
    with open(path, 'wb') as f:
        f.write(b'BTEX'); f.write(struct.pack('<I', len(items)))
        table = f.tell(); f.write(b'\0' * 16 * len(items))
        ent = []
        for (w, h, fmt, data) in items:
            while f.tell() % 16: f.write(b'\0')
            ent.append((w, h, fmt, f.tell(), len(data))); f.write(data)
        f.seek(table)
        for (w, h, fmt, off, sz) in ent: f.write(struct.pack('<HHIII', w, h, fmt, off, sz))

# ------------------------------------------------------------------ sprites
SPRITES = [
    # id, archivo, (alto_mundo, ancho_mundo) -> ancho calculado por aspecto
    ('SPR_BALDI',       'Baldi_Slap0000.png',   9.0),
    ('SPR_BALDI_SLAP',  'Baldi_Slap0012.png',   9.0),
    ('SPR_PRINCIPAL',   'Principal.png',        9.0),
    ('SPR_BULLY',       'bully_final.png',      7.0),
    ('SPR_CRAFTERS',    'Crafters_Normal.png',  8.0),
    ('SPR_PLAYTIME',    'JumpRope_None.png',    8.0),
    ('SPR_SWEEP',       'Gotta Sweep Sprite.png', 8.0),
    ('SPR_PRIZE',       '1PR_0.png',            5.0),
    ('SPR_FACE',        'PlaceFace.png',        8.0),
    ('SPR_NB_YELLOW',   '_nbYellow.png',        3.0),
    ('SPR_NB_GREEN',    '_nbGreen.png',         3.0),
    ('SPR_NB_SALMON',   '_nbSalmon.png',        3.0),
    ('SPR_ITEM_ZESTY',  'EnergyFlavoredZestyBar.png', 2.5),
    ('SPR_ITEM_LOCK',   'YellowDoorLock.png',   2.5),
    ('SPR_ITEM_KEY',    'Key.png',              2.5),
    ('SPR_ITEM_BSODA',  'BSODA.png',            2.5),
    ('SPR_ITEM_QUARTER','Quarter.png',          2.5),
    ('SPR_ITEM_TAPE',   'Tape.png',             2.5),
    ('SPR_ITEM_ALARM',  'AlarmClock.png',       2.5),
    ('SPR_ITEM_WD3D',   'wd_nosquee.png',       2.5),
    ('SPR_ITEM_SCISSORS', 'SafetyScissors.png', 2.5),
    ('SPR_ITEM_BOOTS',  'BigBoots.png',         2.5),
    ('SPR_ITEM_TELEPORT', 'Teleporter.png',     2.5),
]

def build_sprites(proj, out):
    items = []; ids = []; sizes = []
    for i, (sid, fn, height) in enumerate(SPRITES):
        try:
            p = find(proj, fn)
        except FileNotFoundError:
            # buscar variantes (nombre parecido)
            cand = [h for h in glob.glob(os.path.join(proj, 'Assets/Texture2D/**/*.png'), recursive=True)
                    if os.path.splitext(fn)[0].lower() in os.path.basename(h).lower()]
            if not cand:
                print('  (!) sprite no encontrado:', fn, ' -> hueco transparente')
                items.append((8, 8, 1, b'\0' * 128)); ids.append(sid); sizes.append((height, height)); continue
            p = cand[0]
        im = Image.open(p)
        aspect = im.size[0] / im.size[1]
        items.append(to_psp(im, 128))
        ids.append(sid); sizes.append((height * aspect, height))
    # fuente: atlas 128x128, celdas 8x16, caracteres ASCII 32..127 (16 columnas)
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf', 13)
    atlas = Image.new('RGBA', (128, 128), (0, 0, 0, 0)); d = ImageDraw.Draw(atlas)
    for c in range(32, 128):
        cx, cy = ((c - 32) % 16) * 8, ((c - 32) // 16) * 16
        d.text((cx, cy), chr(c), font=font, fill=(255, 255, 255, 255))
    arr = np.array(atlas).astype(np.uint32)
    px = (arr[..., 0] >> 4) | ((arr[..., 1] >> 4) << 4) | ((arr[..., 2] >> 4) << 8) | ((arr[..., 3] >> 4) << 12)
    items.append((128, 128, 2, px.astype('<u2').tobytes())); ids.append('SPR_FONT'); sizes.append((8, 16))
    # texturas 1x1 de color solido (para rectangulos del HUD): blanco
    items.append((8, 8, 0, struct.pack('<H', 0xFFFF) * 64)); ids.append('SPR_WHITE'); sizes.append((1, 1))
    write_pack(os.path.join(out, 'sprites.bin'), items)
    with open(os.path.join(out, 'sprite_ids.h'), 'w') as f:
        f.write('/* generado por convert_assets.py */\n#ifndef SPRITE_IDS_H\n#define SPRITE_IDS_H\n')
        for i, s in enumerate(ids): f.write('#define %s %d\n' % (s, i))
        f.write('#define SPRITE_COUNT %d\n' % len(ids))
        f.write('static const float sprite_world_size[SPRITE_COUNT][2] = {\n')
        for (w, h) in sizes: f.write('  {%.3ff, %.3ff},\n' % (w, h))
        f.write('};\n#endif\n')
    print('sprites:', len(items), os.path.getsize(os.path.join(out, 'sprites.bin')) // 1024, 'KB')

# ------------------------------------------------------------------ audio
SOUNDS = [
    ('SND_SLAP',      'BAL_Slap.wav'),
    ('SND_DOOR_OPEN', 'door_open.wav'),
    ('SND_DOOR_CLOSE', 'door_close.wav'),
    ('SND_SWING',     'swingdoor_open.wav'),
    ('SND_BUZZ',      'Buzz.wav'),
    ('SND_HANG',      'mus_hang.wav'),
    ('SND_BELL',      'bell.wav'),
    ('SND_TICK',      'clocktick.wav'),
    ('SND_SODA',      'soda_spray.wav'),
    ('SND_SPRAY',     'can_spray.wav'),
    ('SND_TELEPORT',  'Teleport.wav'),
    ('SND_PRIZE',     'BAL_GetPrize.wav'),
    ('SND_ALL_NB',    'BAL_AllNotebooks.wav'),
    ('SND_INTRO',     'BAL_Math_Intro.wav'),
    ('SND_HOWTO',     'BAL_General_HowTo.wav'),
    ('SND_PROB1',     'BAL_General_Problem1.wav'),
    ('SND_PROB2',     'BAL_General_Problem2.wav'),
    ('SND_PROB3',     'BAL_General_Problem3.wav'),
    ('SND_PLUS',      'BAL_Math_Plus.wav'),
    ('SND_MINUS',     'BAL_Math_Minus.wav'),
    ('SND_TIMES',     'BAL_Math_Times.wav'),
    ('SND_EQUALS',    'BAL_Math_Equals.wav'),
    ('SND_SCREECH',   'BAL_Screech.wav'),
    ('SND_PRAISE1',   'BAL_Praise1.wav'),
    ('SND_PRAISE2',   'BAL_Praise2.wav'),
    ('SND_PRAISE3',   'BAL_Praise3.wav'),
    ('SND_PRAISE4',   'BAL_Praise4.wav'),
    ('SND_PRAISE5',   'BAL_Praise5.wav'),
] + [('SND_NUM%d' % i, 'BAL_Math_%d.wav' % i) for i in range(10)] + [
    ('SND_MUS_SCHOOL', 'mus_School.wav'),
    ('SND_MUS_LEARN',  'mus_Learn.wav'),
]

def build_sounds(proj, out):
    blobs = []; ids = []
    for sid, fn in SOUNDS:
        try:
            p = find(proj, fn)
        except FileNotFoundError:
            print('  (!) audio no encontrado:', fn); blobs.append(b''); ids.append(sid); continue
        cmd = ['ffmpeg', '-v', 'error', '-y', '-i', p, '-ac', '1', '-ar', str(RATE), '-f', 's16le', '-']
        data = subprocess.run(cmd, capture_output=True).stdout
        # normaliza ligeramente y limita musica larga a 40 s
        if sid.startswith('SND_MUS') and len(data) > RATE * 2 * 40: data = data[:RATE * 2 * 40]
        blobs.append(data); ids.append(sid)
    with open(os.path.join(out, 'sounds.bin'), 'wb') as f:
        f.write(b'BSND'); f.write(struct.pack('<II', len(blobs), RATE))
        table = f.tell(); f.write(b'\0' * 8 * len(blobs))
        ent = []
        for b in blobs:
            while f.tell() % 4: f.write(b'\0')
            ent.append((f.tell(), len(b) // 2)); f.write(b)
        f.seek(table)
        for off, n in ent: f.write(struct.pack('<II', off, n))
    with open(os.path.join(out, 'sound_ids.h'), 'w') as f:
        f.write('/* generado por convert_assets.py */\n#ifndef SOUND_IDS_H\n#define SOUND_IDS_H\n')
        for i, s in enumerate(ids): f.write('#define %s %d\n' % (s, i))
        f.write('#define SOUND_COUNT %d\n#endif\n' % len(ids))
    print('sonidos:', len(blobs), os.path.getsize(os.path.join(out, 'sounds.bin')) // 1024, 'KB')

if __name__ == '__main__':
    proj, out = sys.argv[1], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    build_sprites(proj, out)
    build_sounds(proj, out)
