/* generado por convert_assets.py */
#ifndef SPRITE_IDS_H
#define SPRITE_IDS_H
#define SPR_BALDI 0
#define SPR_BALDI_SLAP 1
#define SPR_PRINCIPAL 2
#define SPR_BULLY 3
#define SPR_CRAFTERS 4
#define SPR_PLAYTIME 5
#define SPR_SWEEP 6
#define SPR_PRIZE 7
#define SPR_FACE 8
#define SPR_NB_YELLOW 9
#define SPR_NB_GREEN 10
#define SPR_NB_SALMON 11
#define SPR_ITEM_ZESTY 12
#define SPR_ITEM_LOCK 13
#define SPR_ITEM_KEY 14
#define SPR_ITEM_BSODA 15
#define SPR_ITEM_QUARTER 16
#define SPR_ITEM_TAPE 17
#define SPR_ITEM_ALARM 18
#define SPR_ITEM_WD3D 19
#define SPR_ITEM_SCISSORS 20
#define SPR_ITEM_BOOTS 21
#define SPR_ITEM_TELEPORT 22
#define SPR_FONT 23
#define SPR_WHITE 24
#define SPRITE_COUNT 25
static const float sprite_world_size[SPRITE_COUNT][2] = {
  {3.727f, 9.000f},
  {3.727f, 9.000f},
  {4.500f, 9.000f},
  {7.000f, 7.000f},
  {4.398f, 8.000f},
  {8.809f, 8.000f},
  {8.000f, 8.000f},
  {5.000f, 5.000f},
  {6.344f, 8.000f},
  {2.367f, 3.000f},
  {2.367f, 3.000f},
  {2.367f, 3.000f},
  {2.500f, 2.500f},
  {2.500f, 2.500f},
  {2.500f, 2.500f},
  {2.500f, 2.500f},
  {2.500f, 2.500f},
  {2.500f, 2.500f},
  {2.500f, 2.500f},
  {2.500f, 2.500f},
  {2.500f, 2.500f},
  {2.500f, 2.500f},
  {2.500f, 2.500f},
  {8.000f, 16.000f},
  {1.000f, 1.000f},
};
#endif
