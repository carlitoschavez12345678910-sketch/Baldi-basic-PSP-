/* Baldi's Basics Classic - port a PSP. Bucle principal, entrada y carga de datos. */
#include <pspkernel.h>
#include <pspdebug.h>
#include <pspctrl.h>
#include <psprtc.h>
#include <psppower.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "platform.h"
#include "sound_ids.h"

PSP_MODULE_INFO("BaldiPSP", PSP_MODULE_USER, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER | THREAD_ATTR_VFPU);
PSP_HEAP_SIZE_KB(-2048);                 /* toda la memoria menos 2 MB */

static int exit_callback(int a1, int a2, void *c) { sceKernelExitGame(); return 0; }
static int callback_thread(SceSize args, void *argp) {
    int cb = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
    sceKernelRegisterExitCallback(cb); sceKernelSleepThreadCB(); return 0;
}
static void setup_callbacks(void) {
    int th = sceKernelCreateThread("update_thread", callback_thread, 0x11, 0xFA0, 0, 0);
    if (th >= 0) sceKernelStartThread(th, 0, 0);
}

static Level lv; static TexPack sprites; static SoundPack snd; static Game G;

static float axis(unsigned char v) { float f = ((int)v - 128) / 127.0f; if (fabsf(f) < 0.18f) return 0; return f > 0 ? (f - 0.18f) / 0.82f : (f + 0.18f) / 0.82f; }

static void fatal(const char *m) {
    pspDebugScreenInit(); pspDebugScreenPrintf("ERROR: %s\n\nCopia la carpeta 'data' junto al EBOOT.PBP.\nPulsa HOME para salir.\n", m);
    sceKernelSleepThread();
}

int main(int argc, char **argv) {
    setup_callbacks();
    scePowerSetClockFrequency(333, 333, 166);
    char dir[256] = "";
    if (argc > 0 && argv[0]) { strncpy(dir, argv[0], sizeof dir - 1); char *s = strrchr(dir, '/'); if (s) s[1] = 0; else dir[0] = 0; }
    /* busca la carpeta data/ en varias ubicaciones posibles (consola, PPSSPP, ejecucion desde otra ruta) */
    const char *bases[] = {dir, "", "ms0:/PSP/GAME/BaldiPSP/", "umd0:/", "host0:/"};
    char base[300] = ""; bool found = false; char p[320];
    for (unsigned i = 0; i < sizeof bases / sizeof *bases && !found; i++) {
        snprintf(p, sizeof p, "%sdata/level.bin", bases[i]);
        FILE *f = fopen(p, "rb"); if (f) { fclose(f); snprintf(base, sizeof base, "%s", bases[i]); found = true; }
    }
    if (!found) fatal("no encuentro data/level.bin");
    snprintf(p, sizeof p, "%sdata/level.bin", base);     if (!level_load(&lv, p)) fatal("error al leer data/level.bin");
    snprintf(p, sizeof p, "%sdata/textures.bin", base);  if (!texpack_load(&lv.tex, p)) fatal("falta data/textures.bin");
    snprintf(p, sizeof p, "%sdata/sprites.bin", base);   if (!texpack_load(&sprites, p)) fatal("falta data/sprites.bin");
    snprintf(p, sizeof p, "%sdata/sounds.bin", base);    if (!soundpack_load(&snd, p)) fatal("falta data/sounds.bin");

    sceCtrlSetSamplingCycle(0); sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    render_init(&lv, &sprites);
    audio_init(&snd);
    for (int i = 0; i < SOUND_COUNT && i < 64; i++) G.sndLen[i] = (float)snd.n[i] / (float)snd.rate;

    u64 tick0; sceRtcGetCurrentTick(&tick0); u32 res = sceRtcGetTickResolution();
    u64 last = tick0; uint32_t buttonsPrev = 0; float t = 0;
    int screen = 0; int music = -1; SceCtrlData pad;
    game_init(&G, &lv, (uint32_t)(tick0 & 0xFFFFFFFF));
    while (1) {
        u64 now; sceRtcGetCurrentTick(&now); float dt = (float)(now - last) / (float)res; last = now; if (dt > 0.1f) dt = 0.1f; t += dt;
        sceCtrlPeekBufferPositive(&pad, 1);
        uint32_t b = pad.Buttons, edge = b & ~buttonsPrev; buttonsPrev = b;
        if (screen == 0) {
            render_title(t);
            if (edge & PSP_CTRL_START) { screen = 1; game_init(&G, &lv, (uint32_t)now); }
            continue;
        }
        Input in; memset(&in, 0, sizeof in);
        in.fwd = -axis(pad.Ly); in.turn = axis(pad.Lx);
        in.strafe = ((b & PSP_CTRL_RTRIGGER) ? 1.0f : 0.0f) - ((b & PSP_CTRL_LTRIGGER) ? 1.0f : 0.0f);
        if (b & PSP_CTRL_CIRCLE) in.held |= BTN_RUN;
        if (edge & PSP_CTRL_CROSS) in.pressed |= BTN_INTERACT;
        if (edge & PSP_CTRL_SQUARE) in.pressed |= BTN_USE;
        if (edge & PSP_CTRL_TRIANGLE) in.pressed |= BTN_MINUS;
        if (edge & PSP_CTRL_START) in.pressed |= BTN_PAUSE;
        if (edge & PSP_CTRL_UP) in.pressed |= BTN_UP;
        if (edge & PSP_CTRL_DOWN) in.pressed |= BTN_DOWN;
        if (edge & PSP_CTRL_LEFT) in.pressed |= BTN_LEFT | BTN_PREV;
        if (edge & PSP_CTRL_RIGHT) in.pressed |= BTN_RIGHT | BTN_NEXT;
        if (G.state != ST_PLAYING) {
            if (G.gameOverT > 2.5f && (edge & PSP_CTRL_START)) { game_init(&G, &lv, (uint32_t)now); music = -1; }
        }
        int prevState = G.state;
        game_update(&G, &in, dt);
        if (G.state == ST_GAMEOVER && prevState == ST_PLAYING) { audio_music(-1, 0); music = -1; audio_play(SND_BUZZ, 1.0f); }
        for (int i = 0; i < G.nSnd; i++) audio_play(G.snd[i], G.sndVol[i]);
        int want = G.state != ST_PLAYING ? -1 : (G.music == MUS_SCHOOL ? SND_MUS_SCHOOL : (G.music == MUS_LEARN ? SND_MUS_LEARN : -1));
        if (want != music) { music = want; audio_music(want, 0.35f); }
        render_game(&G);
    }
    return 0;
}
