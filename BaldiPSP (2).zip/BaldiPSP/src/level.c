#include "level.h"
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <math.h>

static uint8_t *read_all(const char *path, size_t *sz) {
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "no se pudo abrir %s\n", path); return NULL; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *p = (uint8_t *)memalign(16, ((size_t)n + 15) & ~(size_t)15);
    if (!p) { fclose(f); return NULL; }
    if (fread(p, 1, n, f) != (size_t)n) { fclose(f); free(p); return NULL; }
    fclose(f); if (sz) *sz = n; return p;
}

bool level_load(Level *lv, const char *path) {
    memset(lv, 0, sizeof(*lv));
    uint8_t *d = read_all(path, NULL);
    if (!d || memcmp(d, "BLVL", 4)) return false;
    lv->blob = d;
    memcpy(lv->spawn, d + 8, 12);
    memcpy(&lv->navCell, d + 20, 4);
    uint32_t cnt[16], off[16];
    memcpy(cnt, d + 24, 64); memcpy(off, d + 88, 64);
    lv->nQuads = cnt[0]; lv->nDQuads = cnt[1]; lv->nSegs = cnt[2]; lv->nGroups = cnt[3];
    lv->nPickups = cnt[4]; lv->nNotebooks = cnt[5]; lv->nWaypoints = cnt[6]; lv->nMachines = cnt[7];
    lv->nTriggers = cnt[9]; lv->nTex = cnt[11];
    lv->quads = (LvQuad *)(d + off[0]); lv->dquads = (LvQuad *)(d + off[1]);
    lv->segs = (LvSeg *)(d + off[2]); lv->groups = (LvGroup *)(d + off[3]);
    lv->pickups = (LvPickup *)(d + off[4]); lv->notebooks = (LvVec3 *)(d + off[5]);
    lv->waypoints = (LvVec3 *)(d + off[6]); lv->machines = (LvMachine *)(d + off[7]);
    lv->npcStart = (LvVec3 *)(d + off[8]); lv->triggers = (LvTrigger *)(d + off[9]);
    uint8_t *nav = d + off[10];
    memcpy(&lv->navX0, nav, 4); memcpy(&lv->navZ0, nav + 4, 4);
    uint32_t w, h; memcpy(&w, nav + 8, 4); memcpy(&h, nav + 12, 4);
    lv->navW = w; lv->navH = h; lv->navBits = nav + 16;
    lv->texAlpha = d + off[11]; lv->extra = (LvExtra *)(d + off[12]);
    lv->qcx = (float *)malloc(sizeof(float) * 4 * lv->nQuads);
    lv->qcy = lv->qcx + lv->nQuads; lv->qcz = lv->qcy + lv->nQuads; lv->qr = lv->qcz + lv->nQuads;
    for (int i = 0; i < lv->nQuads; i++) {
        float cx = 0, cy = 0, cz = 0;
        for (int k = 0; k < 4; k++) { cx += lv->quads[i].p[k][0]; cy += lv->quads[i].p[k][1]; cz += lv->quads[i].p[k][2]; }
        cx /= 4; cy /= 4; cz /= 4; float r = 0;
        for (int k = 0; k < 4; k++) {
            float dx = lv->quads[i].p[k][0] - cx, dy = lv->quads[i].p[k][1] - cy, dz = lv->quads[i].p[k][2] - cz;
            float q = sqrtf(dx * dx + dy * dy + dz * dz); if (q > r) r = q;
        }
        lv->qcx[i] = cx; lv->qcy[i] = cy; lv->qcz[i] = cz; lv->qr[i] = r;
    }
    return true;
}

bool texpack_load(TexPack *tp, const char *path) {
    uint8_t *d = read_all(path, NULL);
    if (!d || memcmp(d, "BTEX", 4)) return false;
    uint32_t n; memcpy(&n, d + 4, 4);
    tp->count = n; tp->base = d; tp->e = (TexEntry *)(d + 8);
    return true;
}

bool soundpack_load(SoundPack *sp, const char *path) {
    uint8_t *d = read_all(path, NULL);
    if (!d || memcmp(d, "BSND", 4)) return false;
    uint32_t n; memcpy(&n, d + 4, 4); memcpy(&sp->rate, d + 8, 4);
    sp->count = n; sp->blob = d;
    sp->off = (uint32_t *)malloc(8 * n); sp->n = sp->off + n;
    for (uint32_t i = 0; i < n; i++) { memcpy(&sp->off[i], d + 12 + i * 8, 4); memcpy(&sp->n[i], d + 16 + i * 8, 4); }
    return true;
}

/* ------------------------------ navegacion ------------------------------ */
bool nav_walkable(const Level *lv, int cx, int cz) {
    if (cx < 0 || cz < 0 || cx >= lv->navW || cz >= lv->navH) return false;
    uint32_t i = (uint32_t)cz * lv->navW + cx;
    return (lv->navBits[i >> 3] >> (7 - (i & 7))) & 1;
}
void nav_world_to_cell(const Level *lv, float x, float z, int *cx, int *cz) {
    *cx = (int)floorf((x - lv->navX0) / lv->navCell); *cz = (int)floorf((z - lv->navZ0) / lv->navCell);
}

/* A* sobre la rejilla, 8 vecinos. Escribe puntos de ruta (centros de celda) en outx/outz. */
#define MAXN (400 * 400)
static float g_cost[MAXN]; static int32_t g_from[MAXN]; static uint8_t g_state[MAXN];
static int32_t g_heap[MAXN]; static float g_hf[MAXN]; static int g_hn;
static void heap_push(int32_t n, float f) {
    int i = g_hn++; while (i > 0) { int p = (i - 1) >> 1; if (g_hf[p] <= f) break; g_heap[i] = g_heap[p]; g_hf[i] = g_hf[p]; i = p; }
    g_heap[i] = n; g_hf[i] = f;
}
static int32_t heap_pop(void) {
    int32_t top = g_heap[0]; g_hn--; if (g_hn > 0) {
        int32_t n = g_heap[g_hn]; float f = g_hf[g_hn]; int i = 0;
        for (;;) { int c = 2 * i + 1; if (c >= g_hn) break; if (c + 1 < g_hn && g_hf[c + 1] < g_hf[c]) c++; if (g_hf[c] >= f) break; g_heap[i] = g_heap[c]; g_hf[i] = g_hf[c]; i = c; }
        g_heap[i] = n; g_hf[i] = f; }
    return top;
}
static bool nearest_walkable(const Level *lv, int *cx, int *cz) {
    if (nav_walkable(lv, *cx, *cz)) return true;
    for (int r = 1; r < 8; r++)
        for (int dz = -r; dz <= r; dz++) for (int dx = -r; dx <= r; dx++) {
            if (abs(dx) != r && abs(dz) != r) continue;
            if (nav_walkable(lv, *cx + dx, *cz + dz)) { *cx += dx; *cz += dz; return true; }
        }
    return false;
}
bool nav_find_path(const Level *lv, float sx, float sz, float gx, float gz, float *outx, float *outz, int maxPts, int *nOut) {
    int W = lv->navW, H = lv->navH; *nOut = 0;
    if (W * H > MAXN) return false;
    int scx, scz, gcx, gcz;
    nav_world_to_cell(lv, sx, sz, &scx, &scz); nav_world_to_cell(lv, gx, gz, &gcx, &gcz);
    if (!nearest_walkable(lv, &scx, &scz) || !nearest_walkable(lv, &gcx, &gcz)) return false;
    memset(g_state, 0, (size_t)W * H);
    int32_t s = scz * W + scx, g = gcz * W + gcx;
    g_hn = 0; g_cost[s] = 0; g_from[s] = -1; g_state[s] = 1;
    heap_push(s, 0);
    static const int DX[8] = {1, -1, 0, 0, 1, 1, -1, -1}, DZ[8] = {0, 0, 1, -1, 1, -1, 1, -1};
    bool found = false;
    while (g_hn > 0) {
        int32_t n = heap_pop();
        if (g_state[n] == 2) continue;
        g_state[n] = 2;
        if (n == g) { found = true; break; }
        int cx = n % W, cz = n / W;
        for (int k = 0; k < 8; k++) {
            int nx = cx + DX[k], nz = cz + DZ[k];
            if (!nav_walkable(lv, nx, nz)) continue;
            if (k >= 4 && (!nav_walkable(lv, cx + DX[k], cz) || !nav_walkable(lv, cx, cz + DZ[k]))) continue;  /* sin cortar esquinas */
            int32_t m = nz * W + nx; if (g_state[m] == 2) continue;
            float c = g_cost[n] + (k < 4 ? 1.0f : 1.4142f);
            if (g_state[m] == 0 || c < g_cost[m]) {
                g_cost[m] = c; g_from[m] = n; g_state[m] = 1;
                float hx = (float)(gcx - nx), hz = (float)(gcz - nz);
                heap_push(m, c + sqrtf(hx * hx + hz * hz));
            }
        }
    }
    if (!found) return false;
    /* reconstruir (inverso) */
    int cnt = 0; int32_t n = g; static int32_t tmp[MAXN / 4 + 1];
    while (n >= 0 && cnt < MAXN / 4) { tmp[cnt++] = n; n = g_from[n]; }
    /* tmp[cnt-1] es el inicio; emitir en orden con submuestreo cuando hay muchos puntos */
    int out = 0; int step = cnt > maxPts ? (cnt + maxPts - 1) / maxPts : 1;
    for (int i = cnt - 2; i >= 0 && out < maxPts; i -= step) {
        int32_t c = tmp[i];
        outx[out] = lv->navX0 + ((c % W) + 0.5f) * lv->navCell; outz[out] = lv->navZ0 + ((c / W) + 0.5f) * lv->navCell; out++;
    }
    if (out == 0 && cnt >= 1) { outx[0] = gx; outz[0] = gz; out = 1; }
    *nOut = out; return true;
}
