/* generado por convert_assets.py */
#ifndef SOUND_IDS_H
#define SOUND_IDS_H
#define SND_SLAP 0
#define SND_DOOR_OPEN 1
#define SND_DOOR_CLOSE 2
#define SND_SWING 3
#define SND_BUZZ 4
#define SND_HANG 5
#define SND_BELL 6
#define SND_TICK 7
#define SND_SODA 8
#define SND_SPRAY 9
#define SND_TELEPORT 10
#define SND_PRIZE 11
#define SND_ALL_NB 12
#define SND_INTRO 13
#define SND_HOWTO 14
#define SND_PROB1 15
#define SND_PROB2 16
#define SND_PROB3 17
#define SND_PLUS 18
#define SND_MINUS 19
#define SND_TIMES 20
#define SND_EQUALS 21
#define SND_SCREECH 22
#define SND_PRAISE1 23
#define SND_PRAISE2 24
#define SND_PRAISE3 25
#define SND_PRAISE4 26
#define SND_PRAISE5 27
#define SND_NUM0 28
#define SND_NUM1 29
#define SND_NUM2 30
#define SND_NUM3 31
#define SND_NUM4 32
#define SND_NUM5 33
#define SND_NUM6 34
#define SND_NUM7 35
#define SND_NUM8 36
#define SND_NUM9 37
#define SND_MUS_SCHOOL 38
#define SND_MUS_LEARN 39
#define SOUND_COUNT 40
#endif
