#ifndef PLATFORM_H
#define PLATFORM_H
#include "game.h"
#include "sprite_ids.h"

/* render_psp.c */
bool render_init(Level *lv, TexPack *sprites);
void render_title(float t);
void render_game(const Game *g);

/* audio_psp.c */
bool audio_init(const SoundPack *sp);
void audio_play(int id, float vol);
void audio_music(int id, float vol);     /* id < 0: parar */
void audio_shutdown(void);
#endif
