#ifndef LEVEL_H
#define LEVEL_H
#include <stdint.h>
#include <stdbool.h>

/* Estructuras identicas al binario que genera tools/export_level.py */
typedef struct { float p[4][3]; float uv[4][2]; uint16_t tex, texalt, texlock, grp; } LvQuad;   /* 88 */
typedef struct { float x1, z1, x2, z2, y0, y1; uint16_t grp, pad; } LvSeg;                      /* 28 */
typedef struct { float x, y, z; uint32_t kind; float dist; } LvGroup;                           /* 20 */
typedef struct { float x, y, z; uint16_t type, active; } LvPickup;                              /* 16 */
typedef struct { float x, y, z; } LvVec3;                                                       /* 12 */
typedef struct { float x, y, z; uint32_t id; } LvMachine;                                       /* 16 */
typedef struct { uint32_t kind; float x0, z0, x1, z1; uint32_t ent; } LvTrigger;                /* 24 */
typedef struct { float px, pz, dx, dz; uint32_t officeDoor; } LvExtra;                          /* 20 */

enum { GRP_DOOR = 0, GRP_SWING = 1, GRP_ENTRANCE = 2 };
enum { TRG_FACULTY = 1, TRG_EXIT = 2, TRG_NEAREXIT = 3 };
#define NO_GROUP 0xFFFF
#define MAX_GROUPS 32

typedef struct { uint16_t w, h; uint32_t fmt, off, size; } TexEntry;
typedef struct { int count; TexEntry *e; uint8_t *base; } TexPack;

typedef struct {
    uint8_t *blob;
    float spawn[3];
    int nQuads, nDQuads, nSegs, nGroups, nPickups, nNotebooks, nWaypoints, nMachines, nTriggers, nTex;
    LvQuad *quads, *dquads; LvSeg *segs; LvGroup *groups; LvPickup *pickups;
    LvVec3 *notebooks, *waypoints, *npcStart; LvMachine *machines; LvTrigger *triggers;
    uint8_t *texAlpha; LvExtra *extra;
    /* rejilla de navegacion */
    float navX0, navZ0, navCell; int navW, navH; uint8_t *navBits;
    /* bounds esfericos precomputados para quads estaticos */
    float *qcx, *qcy, *qcz, *qr;
    TexPack tex;
} Level;

typedef struct { int count; uint32_t rate; uint32_t *off; uint32_t *n; uint8_t *blob; } SoundPack;

bool level_load(Level *lv, const char *path);
bool texpack_load(TexPack *tp, const char *path);
bool soundpack_load(SoundPack *sp, const char *path);
static inline const int16_t *sound_data(const SoundPack *sp, int id) { return (const int16_t *)(sp->blob + sp->off[id]); }

/* Navegacion */
bool nav_walkable(const Level *lv, int cx, int cz);
void nav_world_to_cell(const Level *lv, float x, float z, int *cx, int *cz);
bool nav_find_path(const Level *lv, float sx, float sz, float gx, float gz, float *outx, float *outz, int maxPts, int *nOut);
#endif
