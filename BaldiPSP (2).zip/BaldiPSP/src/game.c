/* Nucleo de Baldi's Basics Classic para PSP. Independiente de plataforma.
 * Coordenadas = las de Unity (X derecha, Y arriba, Z adelante con yaw 0). */
#include "game.h"
#include "sound_ids.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define PLAYER_R 2.0f
#define PI_F 3.14159265f
#define MAX_NB 16

/* ------------------------------------------------------------ utilidades */
static uint32_t rnd(Game *g) { g->rng ^= g->rng << 13; g->rng ^= g->rng >> 17; g->rng ^= g->rng << 5; return g->rng; }
static float rndf(Game *g) { return (rnd(g) & 0xFFFFFF) / 16777216.0f; }
static int rndi(Game *g, int n) { return (int)(rndf(g) * n) % n; }
static float dist2d(float ax, float az, float bx, float bz) { float dx = ax - bx, dz = az - bz; return sqrtf(dx * dx + dz * dz); }

void game_snd(Game *g, int id, float vol) { if (g->nSnd < MAX_SND) { g->snd[g->nSnd] = id; g->sndVol[g->nSnd++] = vol; } }
static void snd_at(Game *g, int id, float x, float z, float maxd) {   /* sonido posicional simple */
    float d = dist2d(x, z, g->x, g->z); float v = 1.0f - d / maxd; if (v > 0.02f) game_snd(g, id, v);
}
static void say(Game *g, const char *s, float t) { snprintf(g->msg, sizeof g->msg, "%s", s); g->msgT = t; }

const char *item_name(int it) {
    static const char *n[] = {"Nothing", "Energy flavored Zesty Bar", "Yellow Door Lock", "Principal's Keys", "BSODA", "Quarter",
                              "Baldi Anti Hearing and Disorienting Tape", "Alarm Clock", "WD-NoSquee", "Safety Scissors",
                              "Big Ol' Boots", "Teleporter"};
    return (it >= 0 && it <= 11) ? n[it] : "?";
}

/* ------------------------------------------------------------ colisiones */
bool game_door_blocks(const Game *g, const LvSeg *s) {
    if (s->grp == NO_GROUP) return true;
    const LvGroup *gr = &g->lv->groups[s->grp];
    if (gr->kind == GRP_ENTRANCE) {
        float yo = g->entLowered[s->grp] ? -10.0f : 0.0f;
        return (s->y0 + yo) <= 6.5f && (s->y1 + yo) >= 1.5f;
    }
    if (gr->kind == GRP_SWING) return g->door[s->grp].locked;
    return !g->door[s->grp].open;
}

static void push_out(const Game *g, float *x, float *z, float r) {
    const Level *lv = g->lv;
    for (int it = 0; it < 3; it++) {
        bool moved = false;
        for (int i = 0; i < lv->nSegs; i++) {
            const LvSeg *s = &lv->segs[i];
            float minx = (s->x1 < s->x2 ? s->x1 : s->x2) - r, maxx = (s->x1 < s->x2 ? s->x2 : s->x1) + r;
            if (*x < minx || *x > maxx) continue;
            float minz = (s->z1 < s->z2 ? s->z1 : s->z2) - r, maxz = (s->z1 < s->z2 ? s->z2 : s->z1) + r;
            if (*z < minz || *z > maxz) continue;
            if (!game_door_blocks(g, s)) continue;
            float dx = s->x2 - s->x1, dz = s->z2 - s->z1, L2 = dx * dx + dz * dz;
            float t = L2 > 0 ? ((*x - s->x1) * dx + (*z - s->z1) * dz) / L2 : 0; t = t < 0 ? 0 : (t > 1 ? 1 : t);
            float cx = s->x1 + t * dx, cz = s->z1 + t * dz;
            float ex = *x - cx, ez = *z - cz, d2 = ex * ex + ez * ez;
            if (d2 < r * r) {
                float d = sqrtf(d2), nx, nz;
                if (d < 1e-4f) { float L = sqrtf(L2); if (L < 1e-4f) continue; nx = -dz / L; nz = dx / L; }
                else { nx = ex / d; nz = ez / d; }
                *x += nx * (r - d + 0.001f); *z += nz * (r - d + 0.001f); moved = true;
            }
        }
        if (!moved) break;
    }
}

static bool seg_inter(float ax, float az, float bx, float bz, float cx, float cz, float dx, float dz) {
    float d1x = bx - ax, d1z = bz - az, d2x = dx - cx, d2z = dz - cz;
    float den = d1x * d2z - d1z * d2x; if (fabsf(den) < 1e-9f) return false;
    float t = ((cx - ax) * d2z - (cz - az) * d2x) / den, u = ((cx - ax) * d1z - (cz - az) * d1x) / den;
    return t >= 0 && t <= 1 && u >= 0 && u <= 1;
}
static bool los(const Game *g, float x1, float z1, float x2, float z2) {
    const Level *lv = g->lv;
    float minx = x1 < x2 ? x1 : x2, maxx = x1 < x2 ? x2 : x1, minz = z1 < z2 ? z1 : z2, maxz = z1 < z2 ? z2 : z1;
    for (int i = 0; i < lv->nSegs; i++) {
        const LvSeg *s = &lv->segs[i];
        if ((s->x1 < minx && s->x2 < minx) || (s->x1 > maxx && s->x2 > maxx)) continue;
        if ((s->z1 < minz && s->z2 < minz) || (s->z1 > maxz && s->z2 > maxz)) continue;
        if (!game_door_blocks(g, s)) continue;
        if (seg_inter(x1, z1, x2, z2, s->x1, s->z1, s->x2, s->z2)) return false;
    }
    return true;
}

/* ------------------------------------------------------------ NPCs: movimiento */
static void npc_set_dest(Game *g, Npc *n, float x, float z, bool force) {
    if (!force && n->hasDest && n->repath > 0) { n->destx = x; n->destz = z; return; }
    n->destx = x; n->destz = z; n->hasDest = true; n->repath = 0.4f;
    int cnt = 0;
    if (nav_find_path(g->lv, n->x, n->z, x, z, n->px, n->pz, MAX_PATH, &cnt)) { n->plen = cnt; n->pidx = 0; }
    else { n->plen = 0; n->pidx = 0; }
}
static bool npc_arrived(const Npc *n) { return !n->hasDest || (n->pidx >= n->plen && dist2d(n->x, n->z, n->destx, n->destz) < 2.0f); }
static void npc_move(Npc *n, float speed, float dt) {
    n->vx = n->vz = 0;
    if (speed <= 0 || n->stun > 0) return;
    float ox = n->x, oz = n->z, step = speed * dt;
    int guard = 0;
    while (step > 0 && guard++ < 64) {
        float tx, tz;
        if (n->pidx < n->plen) { tx = n->px[n->pidx]; tz = n->pz[n->pidx]; }
        else if (n->hasDest) { tx = n->destx; tz = n->destz; }
        else break;
        float dx = tx - n->x, dz = tz - n->z, d = sqrtf(dx * dx + dz * dz);
        if (d <= step) { n->x = tx; n->z = tz; step -= d; if (n->pidx < n->plen) n->pidx++; else break; }
        else { n->x += dx / d * step; n->z += dz / d * step; n->yaw = atan2f(dx, dz); step = 0; }
    }
    if (dt > 0) { n->vx = (n->x - ox) / dt; n->vz = (n->z - oz) / dt; }
}
static void npc_warp(Npc *n, float x, float z) { n->x = x; n->z = z; n->hasDest = false; n->plen = n->pidx = 0; }
static void npc_wander(Game *g, Npc *n, int range) {
    int id = rndi(g, range); npc_set_dest(g, n, g->lv->waypoints[id].x, g->lv->waypoints[id].z, true);
}

/* ------------------------------------------------------------ Baldi */
static void baldi_wander(Game *g) { npc_wander(g, &g->npc[NPC_BALDI], g->lv->nWaypoints < 29 ? g->lv->nWaypoints : 29); g->bCool = 1.0f; g->bPriority = 0; }
static void baldi_target(Game *g) { npc_set_dest(g, &g->npc[NPC_BALDI], g->x, g->z, false); g->bCool = 1.0f; g->bPriority = 0; }
static void hear(Game *g, float x, float z, float prio) {
    if (!g->npc[NPC_BALDI].active) return;
    if (!g->bAnti && prio >= g->bPriority) { npc_set_dest(g, &g->npc[NPC_BALDI], x, z, true); g->bPriority = prio; }
}
static void baldi_get_angry(Game *g, float v) {
    g->bAnger += v; if (g->bAnger < 0.5f) g->bAnger = 0.5f;
    g->bBaldiWait = -3.0f * g->bAnger / (g->bAnger + 2.0f / 0.65f) + 3.0f;
}
static void baldi_move(Game *g) {
    Npc *b = &g->npc[NPC_BALDI];
    if (dist2d(b->x, b->z, g->bPrevX, g->bPrevZ) < 0.05f && g->bCool < 0) baldi_wander(g);
    g->bMoveFrames = 10;
    g->bTimeToMove = g->bBaldiWait - g->bTempAnger;
    g->bPrevX = b->x; g->bPrevZ = b->z;
    snd_at(g, SND_SLAP, b->x, b->z, 120.0f);
}
static void baldi_fixed(Game *g) {          /* 50 Hz */
    Npc *b = &g->npc[NPC_BALDI];
    if (g->bMoveFrames > 0) { g->bMoveFrames -= 1; npc_move(b, 75.0f, 0.02f); }
    else b->vx = b->vz = 0;
    g->bSees = los(g, b->x, b->z, g->x, g->z);
    if (g->bSees) baldi_target(g);
}
static void baldi_update(Game *g, float dt) {
    Npc *b = &g->npc[NPC_BALDI];
    b->repath -= dt;
    if (g->bTimeToMove > 0) g->bTimeToMove -= dt; else baldi_move(g);
    if (g->bCool > 0) g->bCool -= dt;
    if (g->bTempAnger > 0) g->bTempAnger -= 0.02f * dt; else g->bTempAnger = 0;
    if (g->bAntiTime > 0) g->bAntiTime -= dt; else g->bAnti = false;
    g->bFixedAcc += dt;
    int guard = 0;
    while (g->bFixedAcc >= 0.02f && guard++ < 8) { g->bFixedAcc -= 0.02f; baldi_fixed(g); }
    if (dist2d(b->x, b->z, g->x, g->z) < 3.2f && g->state == ST_PLAYING) { g->state = ST_GAMEOVER; g->gameOverT = 0; }
}

/* ------------------------------------------------------------ puertas */
static void door_open(Game *g, int i, bool byPlayer) {
    DoorState *d = &g->door[i]; const LvGroup *gr = &g->lv->groups[i];
    if (d->locked && gr->kind == GRP_DOOR) return;
    if (gr->kind == GRP_SWING) {
        if (d->locked) return;
        if (!d->open) { game_snd(g, SND_SWING, 0.8f); if (byPlayer) hear(g, gr->x, gr->z, 1); }
        d->open = true; d->openTime = 2.0f; return;
    }
    if (!d->open && d->silent <= 0) game_snd(g, SND_DOOR_OPEN, 0.9f);
    if (byPlayer && d->silent <= 0) hear(g, gr->x, gr->z, 1);
    d->open = true; d->openTime = 3.0f;
}
static void doors_update(Game *g, float dt) {
    for (int i = 0; i < g->lv->nGroups; i++) {
        const LvGroup *gr = &g->lv->groups[i]; DoorState *d = &g->door[i];
        if (gr->kind == GRP_ENTRANCE) continue;
        if (d->lockTime > 0) d->lockTime -= dt;
        else if (d->locked && (gr->kind == GRP_DOOR || d->req)) d->locked = false;
        if (gr->kind == GRP_SWING && !d->req && g->notebooks >= 2) { d->req = true; d->locked = false; }
        if (d->openTime > 0) d->openTime -= dt;
        if (d->open && d->openTime <= 0) {
            d->open = false;
            if (gr->kind == GRP_DOOR && d->silent <= 0) game_snd(g, SND_DOOR_CLOSE, 0.8f);
        }
        /* puertas de vaiven: se abren al acercarse jugador o NPC; las normales solo NPC */
        float near = 7.0f;
        bool trig = false;
        if (gr->kind == GRP_SWING && g->notebooks >= 2 && dist2d(gr->x, gr->z, g->x, g->z) < near) trig = true;
        for (int n = 0; n < NPC_COUNT && !trig; n++) {
            if (!g->npc[n].active || n == NPC_BULLY) continue;
            if (dist2d(gr->x, gr->z, g->npc[n].x, g->npc[n].z) < near) trig = true;
        }
        if (trig && !d->locked) {
            bool wasOpen = d->open; (void)wasOpen;
            if (gr->kind == GRP_SWING) { if (!d->open) game_snd(g, SND_SWING, 0.6f); d->open = true; d->openTime = 2.0f; }
            else door_open(g, i, false);
        }
    }
}

/* ------------------------------------------------------------ interaccion */
static float facing_cos(const Game *g, float tx, float tz) {
    float dx = tx - g->x, dz = tz - g->z, d = sqrtf(dx * dx + dz * dz); if (d < 1e-4f) return 1;
    return (dx * sinf(g->yaw) + dz * cosf(g->yaw)) / d;
}
/* los hasta un objeto que puede estar sobre un escritorio: se corta 3.5 u antes del objeto */
static bool los_to_item(const Game *g, float tx, float tz) {
    float dx = tx - g->x, dz = tz - g->z, d = sqrtf(dx * dx + dz * dz);
    if (d < 3.6f) return true;
    float k = (d - 3.5f) / d;
    return los(g, g->x, g->z, g->x + dx * k, g->z + dz * k);
}
typedef enum { T_NONE, T_PICKUP, T_NOTEBOOK, T_DOOR, T_MACHINE } TKind;
static TKind find_target(const Game *g, int *idx, float maxd) {
    const Level *lv = g->lv; TKind best = T_NONE; float bestc = 0.84f; *idx = -1;
    for (int i = 0; i < lv->nPickups; i++) if (g->pickupOn[i]) {
        float d = dist2d(lv->pickups[i].x, lv->pickups[i].z, g->x, g->z); if (d > maxd) continue;
        float c = facing_cos(g, lv->pickups[i].x, lv->pickups[i].z);
        if (c > bestc && los_to_item(g, lv->pickups[i].x, lv->pickups[i].z)) { bestc = c; best = T_PICKUP; *idx = i; }
    }
    for (int i = 0; i < lv->nNotebooks; i++) if (g->nbOn[i]) {
        float d = dist2d(lv->notebooks[i].x, lv->notebooks[i].z, g->x, g->z); if (d > maxd) continue;
        float c = facing_cos(g, lv->notebooks[i].x, lv->notebooks[i].z);
        if (c > bestc && los_to_item(g, lv->notebooks[i].x, lv->notebooks[i].z)) { bestc = c; best = T_NOTEBOOK; *idx = i; }
    }
    for (int i = 0; i < lv->nMachines; i++) {
        float d = dist2d(lv->machines[i].x, lv->machines[i].z, g->x, g->z); if (d > maxd + 2) continue;
        float c = facing_cos(g, lv->machines[i].x, lv->machines[i].z) - 0.1f;
        if (c > bestc) { bestc = c; best = T_MACHINE; *idx = i; }
    }
    for (int i = 0; i < lv->nGroups; i++) {
        const LvGroup *gr = &lv->groups[i]; if (gr->kind == GRP_ENTRANCE) continue;
        float d = dist2d(gr->x, gr->z, g->x, g->z); if (d > maxd) continue;
        float c = facing_cos(g, gr->x, gr->z) - 0.1f;
        if (c > bestc) { bestc = c; best = T_DOOR; *idx = i; }
    }
    return best;
}
bool game_target_name(const Game *g, char *out, int n) {
    int i; TKind k = find_target(g, &i, 10.0f);
    switch (k) {
    case T_PICKUP: snprintf(out, n, "%s", item_name(g->lv->pickups[i].type)); return true;
    case T_NOTEBOOK: snprintf(out, n, "Notebook"); return true;
    case T_DOOR: snprintf(out, n, g->lv->groups[i].kind == GRP_SWING ? (g->door[i].locked ? "Locked door" : "Door") : (g->door[i].locked ? "Locked door" : "Open door")); return true;
    case T_MACHINE: { static const char *m[] = {"", "BSODA machine", "Zesty machine", "Pay phone", "Tape player"}; int mid = (int)g->lv->machines[i].id; snprintf(out, n, "%s", m[(mid >= 1 && mid <= 4) ? mid : 0]); return true; }
    default: return false;
    }
}

static void spoop_mode(Game *g) {
    if (g->spoop) return;
    g->spoop = true;
    for (int i = 0; i < g->lv->nGroups; i++) if (g->lv->groups[i].kind == GRP_ENTRANCE) g->entLowered[i] = 1;
    for (int n = 0; n < NPC_COUNT; n++) {
        Npc *p = &g->npc[n]; p->active = true;
        p->x = g->lv->npcStart[n].x; p->z = g->lv->npcStart[n].z; p->hasDest = false; p->plen = 0;
    }
    /* Bully empieza oculto con temporizador */
    g->npc[NPC_BULLY].active = false; g->npc[NPC_BULLY].t1 = 60.0f + rndf(g) * 60.0f;
    g->npc[NPC_CRAFTERS].active = true; g->npc[NPC_PRIZE].t1 = 0;
    g->npc[NPC_SWEEP].t1 = 15.0f + rndf(g) * 15.0f; g->npc[NPC_SWEEP].st = 0;
    baldi_wander(g);
    g->bTimeToMove = 3.0f;
    game_snd(g, SND_HANG, 1.0f); g->music = MUS_NONE;
}

static void collect_item(Game *g, int id) {
    for (int s = 0; s < 3; s++) if (g->item[s] == 0) { g->item[s] = id; return; }
    g->item[g->itemSel] = id;
}

/* ------------------------------------------------------------ juego de mates */
static void mg_queue(Game *g, int snd) { if (g->mg.aqN < 24) g->mg.audioQ[g->mg.aqN++] = snd; }
static void mg_new_problem(Game *g) {
    MathGame *m = &g->mg; m->alen = 0; m->ans[0] = 0; m->problem++;
    if (m->problem <= 3) {
        mg_queue(g, SND_PROB1 + m->problem - 1);
        if (m->problem <= 2 || g->notebooks <= 1) {
            int a = rndi(g, 10), b = rndi(g, 10), sg = rndi(g, 2);
            m->impossible = false;
            mg_queue(g, SND_NUM0 + a);
            if (sg == 0) { m->solution = a + b; snprintf(m->q, sizeof m->q, "%d) %d + %d =", m->problem, a, b); mg_queue(g, SND_PLUS); }
            else { m->solution = a - b; snprintf(m->q, sizeof m->q, "%d) %d - %d =", m->problem, a, b); mg_queue(g, SND_MINUS); }
            mg_queue(g, SND_NUM0 + b); mg_queue(g, SND_EQUALS);
        } else {
            int a = 1 + rndi(g, 9999), b = 1 + rndi(g, 9999), c = 1 + rndi(g, 9999);
            m->impossible = true; m->solution = -1;
            if (rndi(g, 2)) snprintf(m->q, sizeof m->q, "%d) %d + (%d x %d) =", m->problem, a, b, c);
            else snprintf(m->q, sizeof m->q, "%d) (%d / %d) + %d =", m->problem, a, b, c);
            mg_queue(g, SND_SCREECH); mg_queue(g, SND_PLUS); mg_queue(g, SND_SCREECH); mg_queue(g, SND_TIMES); mg_queue(g, SND_SCREECH); mg_queue(g, SND_EQUALS);
        }
    } else {
        m->endDelay = 5.0f; m->aqN = 0;
        if (!g->spoop) snprintf(m->msg, sizeof m->msg, "WOW! YOU EXIST!");
        else if (m->wrong >= 3) { snprintf(m->msg, sizeof m->msg, "I HEAR MATH THAT BAD"); hear(g, g->x, g->z, 7); g->failedNotebooks++; }
        else snprintf(m->msg, sizeof m->msg, rndi(g, 2) ? "GET 3 RIGHT TO MAKE ME GO AWAY" : "THE MORE YOU MISS THE MORE I GROW");
        m->q[0] = 0;
    }
}
static void mg_start(Game *g, int nbIndex) {
    (void)nbIndex; MathGame *m = &g->mg; memset(m, 0, sizeof *m); m->active = true;
    if (!g->spoop) g->music = MUS_LEARN;
    if (g->notebooks == 1) { mg_queue(g, SND_INTRO); mg_queue(g, SND_HOWTO); }
    mg_new_problem(g);
}
static void mg_end(Game *g) {
    g->mg.active = false;
    if (g->stamina < 100) g->stamina = 100;
    if (!g->spoop) g->music = MUS_SCHOOL;
    if (g->notebooks == 1 && !g->spoop) {
        for (int i = 0; i < g->lv->nPickups; i++) if (g->lv->pickups[i].type == 5 && !g->lv->pickups[i].active) { g->pickupOn[i] = 1; break; }
        game_snd(g, SND_PRIZE, 1.0f);
    } else if (g->notebooks == 7) game_snd(g, SND_ALL_NB, 0.8f);
    if (g->notebooks == 7) {
        g->finale = true;
        for (int i = 0; i < g->lv->nGroups; i++) if (g->lv->groups[i].kind == GRP_ENTRANCE) g->entLowered[i] = 0;
    }
}
static void mg_check(Game *g) {
    MathGame *m = &g->mg; if (m->problem > 3) return;
    bool ok = false;
    if (!m->impossible && m->alen > 0) ok = (atof(m->ans) == m->solution);
    m->aqN = 0; m->aqT = 0;
    if (ok) { m->res[m->problem - 1] = 1; mg_queue(g, SND_PRAISE1 + rndi(g, 5)); }
    else {
        m->wrong++; m->res[m->problem - 1] = 2;
        if (!g->spoop) { spoop_mode(g); }
        if (m->problem == 3) baldi_get_angry(g, 1.0f); else g->bTempAnger += 0.25f;
    }
    mg_new_problem(g);
}
static void mg_update(Game *g, const Input *in, float dt) {
    MathGame *m = &g->mg;
    if (m->aqT > 0) m->aqT -= dt;
    else if (m->aqN > 0 && !g->spoop) {
        int s = m->audioQ[0]; for (int i = 1; i < m->aqN; i++) m->audioQ[i - 1] = m->audioQ[i]; m->aqN--;
        game_snd(g, s, 1.0f); m->aqT = g->sndLen[s] + 0.03f;
    }
    if (m->problem > 3) { m->endDelay -= dt; if (m->endDelay <= 0) mg_end(g); return; }
    /* entrada de digitos: arriba/abajo cambia el ultimo digito, derecha anade, izquierda borra, cruz acepta */
    if (in->pressed & BTN_RIGHT) { if (m->alen < 9) { m->ans[m->alen++] = '0'; m->ans[m->alen] = 0; } }
    if (in->pressed & BTN_LEFT) { if (m->alen > 0) m->ans[--m->alen] = 0; }
    if (in->pressed & (BTN_UP | BTN_DOWN)) {
        if (m->alen == 0) { m->ans[0] = '0'; m->ans[1] = 0; m->alen = 1; }
        char *c = &m->ans[m->alen - 1];
        if (*c == '-') *c = (in->pressed & BTN_UP) ? '0' : '9';
        else { int v = *c - '0'; v += (in->pressed & BTN_UP) ? 1 : -1; if (v > 9) v = 0; if (v < 0) v = 9; *c = (char)('0' + v); }
    }
    if (in->pressed & BTN_MINUS) {
        if (m->alen > 0 && m->ans[0] == '-') { memmove(m->ans, m->ans + 1, m->alen); m->alen--; }
        else if (m->alen < 9) { memmove(m->ans + 1, m->ans, m->alen + 1); m->ans[0] = '-'; m->alen++; }
    }
    if (in->pressed & BTN_INTERACT) mg_check(g);
}

/* ------------------------------------------------------------ items */
static int nearest_npc_front(const Game *g, float maxd, float mincos) {
    int best = -1; float bd = maxd;
    for (int n = 0; n < NPC_COUNT; n++) {
        const Npc *p = &g->npc[n]; if (!p->active) continue;
        float d = dist2d(p->x, p->z, g->x, g->z); if (d < bd && facing_cos(g, p->x, p->z) > mincos) { bd = d; best = n; }
    }
    return best;
}
static void use_item(Game *g) {
    int it = g->item[g->itemSel]; if (!it) return;
    int idx; bool used = false; const Level *lv = g->lv;
    if (it == 1) { g->stamina = 200.0f; used = true; }
    else if (it == 2) {  /* candado: puerta de vaiven */
        TKind k = find_target(g, &idx, 10.0f);
        if (k == T_DOOR && lv->groups[idx].kind == GRP_SWING) { g->door[idx].locked = true; g->door[idx].lockTime = 15.0f; g->door[idx].open = false; used = true; }
    } else if (it == 3) {  /* llave */
        TKind k = find_target(g, &idx, 10.0f);
        if (k == T_DOOR && lv->groups[idx].kind == GRP_DOOR && g->door[idx].locked) { g->door[idx].locked = false; g->door[idx].lockTime = 0; door_open(g, idx, true); used = true; }
    } else if (it == 4) {  /* BSODA */
        g->sprayT = 1.2f; g->sprayX = g->x; g->sprayZ = g->z; g->sprayDX = sinf(g->yaw); g->sprayDZ = cosf(g->yaw);
        game_snd(g, SND_SODA, 1.0f); g->guilt = 1.0f; g->guiltType = "drink"; used = true;
    } else if (it == 5) {  /* moneda en maquina */
        TKind k = find_target(g, &idx, 10.0f);
        if (k == T_MACHINE) {
            int id = lv->machines[idx].id;
            if (id == 1) { g->item[g->itemSel] = 0; collect_item(g, 4); return; }
            if (id == 2) { g->item[g->itemSel] = 0; collect_item(g, 1); return; }
            if (id == 3) { g->bAnti = true; g->bAntiTime = 30.0f; baldi_wander(g); game_snd(g, SND_TELEPORT, 0.6f); used = true; }
        }
    } else if (it == 6) {  /* cinta */
        TKind k = find_target(g, &idx, 10.0f);
        if (k == T_MACHINE && lv->machines[idx].id == 4) { g->bAnti = true; g->bAntiTime = 30.0f; baldi_wander(g); game_snd(g, SND_TELEPORT, 0.6f); used = true; }
    } else if (it == 7) { g->alarmOn = true; g->alarmT = 30.0f; g->alarmX = g->x; g->alarmZ = g->z; used = true; game_snd(g, SND_TICK, 0.7f); }
    else if (it == 8) {  /* WD-NoSquee */
        TKind k = find_target(g, &idx, 10.0f);
        if (k == T_DOOR && lv->groups[idx].kind == GRP_DOOR) { g->door[idx].silent = 4; used = true; game_snd(g, SND_SPRAY, 0.8f); }
    } else if (it == 9) {  /* tijeras */
        if (g->freezeT > 0) { g->freezeT = 0; g->npc[NPC_PLAYTIME].t1 = 20.0f; g->npc[NPC_PLAYTIME].st = 0; used = true; }
        else { int n = nearest_npc_front(g, 12.0f, 0.8f); if (n == NPC_PRIZE) { g->npc[NPC_PRIZE].st = 3; g->npc[NPC_PRIZE].t2 = 15.0f; used = true; } }
    } else if (it == 10) { g->bootsActive = true; g->bootsTime = 15.0f; used = true; }
    else if (it == 11) { used = true;
        int w = rndi(g, lv->nWaypoints < 29 ? lv->nWaypoints : 29); g->x = lv->waypoints[w].x; g->z = lv->waypoints[w].z; game_snd(g, SND_TELEPORT, 1.0f); }
    if (used) g->item[g->itemSel] = 0;
}

/* ------------------------------------------------------------ resto de NPCs */
static void npcs_update(Game *g, float dt) {
    const Level *lv = g->lv; (void)lv;
    for (int n = 0; n < NPC_COUNT; n++) { Npc *p = &g->npc[n]; if (p->repath > 0) p->repath -= dt; if (p->stun > 0) p->stun -= dt; }

    /* --- Principal --- */
    { Npc *p = &g->npc[NPC_PRINCIPAL];
      if (p->active) {
        bool seesPlayer = false; p->t3 -= dt;
        if (p->t3 <= 0) { p->t3 = 0.1f; p->vis = los(g, p->x, p->z, g->x, g->z); }
        seesPlayer = p->vis;
        if (p->st == 0) {
            if (seesPlayer && g->guilt > 0) { p->t1 += dt; if (p->t1 >= 0.5f) {
                p->st = 1; p->t1 = 0;
                const char *m = !strcmp(g->guiltType, "running") ? "NO RUNNING IN THE HALLS!" : !strcmp(g->guiltType, "faculty") ? "NO FACULTY ALLOWED!" :
                                !strcmp(g->guiltType, "drink") ? "NO DRINKING IN THE HALLS!" : "COME HERE!";
                say(g, m, 3.0f); } }
            else { p->t1 = 0; if (npc_arrived(p) || p->repath <= -3.0f) { npc_wander(g, p, 29); p->repath = 0; } }
            npc_move(p, 14.0f, dt);
        } else if (p->st == 1) {
            npc_set_dest(g, p, g->x, g->z, false); npc_move(p, 22.0f, dt);
            if (dist2d(p->x, p->z, g->x, g->z) < 4.0f && lv->extra) {
                static const float times[5] = {15, 30, 45, 60, 99};
                float t = times[g->detentions < 4 ? g->detentions : 4]; g->detentions++;
                g->x = lv->extra->dx; g->z = lv->extra->dz;
                npc_warp(p, lv->extra->px, lv->extra->pz); p->st = 2;
                if (lv->extra->officeDoor < (uint32_t)lv->nGroups) { DoorState *d = &g->door[lv->extra->officeDoor]; d->locked = true; d->lockTime = t; d->open = false; }
                char b[48]; snprintf(b, sizeof b, "DETENTION FOR %d SECONDS!", (int)t); say(g, b, 4.0f);
            }
        } else if (p->st == 2) {
            bool locked = lv->extra && lv->extra->officeDoor < (uint32_t)lv->nGroups && g->door[lv->extra->officeDoor].locked;
            if (!locked) { p->st = 0; p->t1 = 0; g->guilt = 0; }
        }
      } }

    /* --- Playtime --- */
    { Npc *p = &g->npc[NPC_PLAYTIME];
      if (p->active) {
        if (p->t1 > 0) p->t1 -= dt;
        p->t3 -= dt; if (p->t3 <= 0) { p->t3 = 0.15f; p->vis = los(g, p->x, p->z, g->x, g->z) && dist2d(p->x, p->z, g->x, g->z) < 70; }
        if (p->st == 0) {
            if (p->vis && p->t1 <= 0) p->st = 1;
            else if (npc_arrived(p)) npc_wander(g, p, 29);
            npc_move(p, 10.0f, dt);
        } else if (p->st == 1) {
            npc_set_dest(g, p, g->x, g->z, false); npc_move(p, 15.0f, dt);
            if (!p->vis && dist2d(p->x, p->z, g->x, g->z) > 70) p->st = 0;
            if (dist2d(p->x, p->z, g->x, g->z) < 4.5f && p->t1 <= 0) { p->st = 2; g->freezeT = 6.0f; say(g, "LET'S PLAY! (USE SCISSORS TO ESCAPE)", 3.0f); }
        } else if (p->st == 2) {
            if (g->freezeT <= 0) { p->st = 0; p->t1 = 20.0f; npc_wander(g, p, 29); }
        }
      } }
    if (g->freezeT > 0) g->freezeT -= dt;

    /* --- 1st Prize --- */
    { Npc *p = &g->npc[NPC_PRIZE];
      if (p->active) {
        p->t3 -= dt; if (p->t3 <= 0) { p->t3 = 0.15f; p->vis = los(g, p->x, p->z, g->x, g->z) && dist2d(p->x, p->z, g->x, g->z) < 80; }
        if (p->t1 > 0) p->t1 -= dt;
        if (p->st == 3) {                 /* loco (tijeras) */
            p->t2 -= dt; if (npc_arrived(p) || p->repath <= -1.0f) { npc_wander(g, p, 29); p->repath = 0; }
            npc_move(p, 40.0f, dt); if (p->t2 <= 0) p->st = 0;
        } else if (p->st == 2) {          /* abrazo */
            p->t2 -= dt; g->hugT = p->t2;
            if (!g->bootsActive) { g->x += p->vx * dt * 1.0f; g->z += p->vz * dt * 1.0f; }
            if (npc_arrived(p)) npc_wander(g, p, 29);
            npc_move(p, 25.0f, dt);
            if (p->t2 <= 0) { p->st = 0; p->t1 = 4.0f; }
        } else {
            float sp = 5.0f;
            if (p->vis && p->t1 <= 0) { npc_set_dest(g, p, g->x, g->z, false); sp = 30.0f; }
            else if (npc_arrived(p)) npc_wander(g, p, 29);
            npc_move(p, sp, dt);
            if (dist2d(p->x, p->z, g->x, g->z) < 4.0f && p->t1 <= 0 && !g->bootsActive) { p->st = 2; p->t2 = 2.0f; npc_wander(g, p, 29); say(g, "I HUG YOU!", 2.0f); }
        }
      } }

    /* --- Gotta Sweep --- */
    { Npc *p = &g->npc[NPC_SWEEP];
      if (p->active) {
        if (p->st == 0) { p->t1 -= dt; if (p->t1 <= 0) { p->st = 1; npc_wander(g, p, 29); } }
        else { npc_move(p, 28.0f, dt); if (npc_arrived(p)) { p->st = 0; p->t1 = 20.0f + rndf(g) * 25.0f; } }
        if (dist2d(p->x, p->z, g->x, g->z) < 4.0f && p->st == 1 && !g->bootsActive) { g->x += p->vx * dt; g->z += p->vz * dt; g->sweepT = 0.3f; }
      } }
    if (g->sweepT > 0) g->sweepT -= dt;

    /* --- Bully (quieto en un pasillo) --- */
    { Npc *p = &g->npc[NPC_BULLY];
      if (g->spoop) {
        if (!p->active) {
            p->t1 -= dt;
            if (p->t1 <= 0) {
                for (int k = 0; k < 20; k++) {
                    int w = 1 + rndi(g, 15); float wx = lv->waypoints[w].x, wz = lv->waypoints[w].z;
                    if (dist2d(wx, wz, g->x, g->z) >= 20.0f) { p->x = wx; p->z = wz; p->active = true; p->t2 = 0; p->st = 0; break; }
                }
            }
        } else {
            p->t2 += dt;
            if (p->t2 >= 180.0f && dist2d(p->x, p->z, g->x, g->z) >= 120.0f) { p->active = false; p->t1 = 60.0f + rndf(g) * 60.0f; }
            if (dist2d(p->x, p->z, g->x, g->z) < 4.5f) {
                if (!g->item[0] && !g->item[1] && !g->item[2]) say(g, "NO ITEMS? NO PASS!", 2.5f);
                else { int s; do { s = rndi(g, 3); } while (!g->item[s]); g->item[s] = 0; say(g, "THE BULLY TOOK YOUR ITEM", 2.5f); }
                p->active = false; p->t1 = 60.0f + rndf(g) * 60.0f;
            }
        }
      } }

    /* --- Arts and Crafters --- */
    { Npc *p = &g->npc[NPC_CRAFTERS];
      if (p->active) {
        bool near = dist2d(p->x, p->z, g->x, g->z) < 60.0f;
        p->t3 -= dt; if (p->t3 <= 0) { p->t3 = 0.15f; p->vis = los(g, p->x, p->z, g->x, g->z); }
        if (p->st == 0) {
            if (npc_arrived(p)) npc_wander(g, p, 29);
            npc_move(p, 10.0f, dt);
            if (g->notebooks >= 7 && p->vis && near) { p->t1 += dt; if (p->t1 >= 1.0f) { p->st = 1; p->t2 = 20.0f; } } else p->t1 = 0;
        } else {
            p->t2 += 60.0f * dt; npc_set_dest(g, p, g->x, g->z, false); npc_move(p, p->t2 > 120 ? 120 : p->t2, dt);
            if (dist2d(p->x, p->z, g->x, g->z) < 4.0f) {
                int w = rndi(g, 29); g->x = lv->waypoints[w].x; g->z = lv->waypoints[w].z;
                game_snd(g, SND_TELEPORT, 1.0f); p->st = 0; p->t1 = 0; npc_wander(g, p, 29);
                int w2 = rndi(g, 29); npc_warp(p, lv->waypoints[w2].x, lv->waypoints[w2].z);
            }
        }
      } }
}

/* ------------------------------------------------------------ init / update */
void game_init(Game *g, Level *lv, uint32_t seed) {
    float keepLen[64]; memcpy(keepLen, g->sndLen, sizeof keepLen);
    memset(g, 0, sizeof *g); memcpy(g->sndLen, keepLen, sizeof keepLen);
    g->lv = lv; g->rng = seed ? seed : 0x9E3779B9u;
    g->x = lv->spawn[0]; g->y = 4.0f; g->z = lv->spawn[2]; g->yaw = 0;       /* mira al norte (+Z) */
    g->stamina = 100; g->state = ST_PLAYING; g->music = MUS_SCHOOL;
    g->bBaldiWait = 3.0f; g->bTimeToMove = 3.0f;
    for (int i = 0; i < lv->nPickups && i < 64; i++) g->pickupOn[i] = lv->pickups[i].active ? 1 : 0;
    for (int i = 0; i < lv->nNotebooks && i < MAX_NB; i++) g->nbOn[i] = 1;
    for (int i = 0; i < lv->nGroups; i++) if (lv->groups[i].kind == GRP_SWING) g->door[i].locked = true;
    for (int n = 0; n < NPC_COUNT; n++) { g->npc[n].x = lv->npcStart[n].x; g->npc[n].z = lv->npcStart[n].z; }
    g->guiltType = "none";
}

void game_update(Game *g, const Input *in, float dt) {
    if (dt > 0.1f) dt = 0.1f;
    g->nSnd = 0;
    if (g->state != ST_PLAYING) { g->gameOverT += dt; return; }
    if (in->pressed & BTN_PAUSE) g->paused = !g->paused;
    if (g->paused) return;
    g->time += dt;
    if (g->msgT > 0) g->msgT -= dt;
    const Level *lv = g->lv;

    if (g->mg.active) {
        mg_update(g, in, dt);
        doors_update(g, dt);          /* el mundo sigue en marcha, pero el jugador esta quieto */
        if (g->npc[NPC_BALDI].active) baldi_update(g, dt);
        return;
    }

    /* --- giro y movimiento --- */
    bool frozen = g->freezeT > 0;
    g->yaw += in->turn * 2.1f * dt;
    if (g->yaw > PI_F) g->yaw -= 2 * PI_F;
    if (g->yaw < -PI_F) g->yaw += 2 * PI_F;
    float fwd = in->fwd, str = in->strafe;
    float len = sqrtf(fwd * fwd + str * str); if (len > 1) { fwd /= len; str /= len; len = 1; }
    bool run = (in->held & BTN_RUN) && g->stamina > 0;
    float speed = run ? 16.0f : 10.0f;
    float mx = sinf(g->yaw) * fwd + cosf(g->yaw) * str, mz = cosf(g->yaw) * fwd - sinf(g->yaw) * str;
    float ox = g->x, oz = g->z;
    if (!frozen) { g->x += mx * speed * dt; g->z += mz * speed * dt; }
    push_out(g, &g->x, &g->z, PLAYER_R);
    float moved = dist2d(g->x, g->z, ox, oz) / (dt > 0 ? dt : 1);
    if (moved > 0.1f) {
        if ((in->held & BTN_RUN) && g->stamina > 0) { g->stamina -= 10.0f * dt; if (g->stamina < 0 && g->stamina > -5.0f) g->stamina = -5.0f;
                                                      if (!g->sweepT && g->hugT <= 0) { g->guilt = 0.1f; g->guiltType = "running"; } }
        if (g->stamina < 0 && g->stamina > -5.0f) g->stamina = -5.0f;
    } else if (g->stamina < 100) g->stamina += 10.0f * dt;
    if (g->stamina <= 0 && !(in->held & BTN_RUN)) { /* recuperacion con el boton suelto */ }
    if (g->guilt > 0) g->guilt -= dt;
    if (g->bootsActive) { g->bootsTime -= dt; if (g->bootsTime <= 0) g->bootsActive = false; }
    if (g->hugT > 0) g->hugT -= dt;

    /* --- triggers --- */
    for (int i = 0; i < lv->nTriggers; i++) {
        const LvTrigger *t = &lv->triggers[i];
        float cx = g->x < t->x0 ? t->x0 : (g->x > t->x1 ? t->x1 : g->x), cz = g->z < t->z0 ? t->z0 : (g->z > t->z1 ? t->z1 : g->z);
        bool inside = dist2d(cx, cz, g->x, g->z) <= PLAYER_R;
        if (!inside) continue;
        if (t->kind == TRG_FACULTY) { if (1.0f >= g->guilt) { g->guilt = 1.0f; g->guiltType = "faculty"; } }
        else if (t->kind == TRG_EXIT) {
            if (g->notebooks >= 7) { g->state = (g->failedNotebooks >= 7) ? ST_SECRET : ST_WON; g->gameOverT = 0; return; }
        } else if (t->kind == TRG_NEAREXIT) {
            if (g->exitsReached < 3 && g->finale && t->ent < (uint32_t)lv->nGroups && !g->entLowered[t->ent]) {
                g->exitsReached++; g->entLowered[t->ent] = 1; hear(g, (t->x0 + t->x1) / 2, (t->z0 + t->z1) / 2, 8.0f);
                if (g->exitsReached == 3) say(g, "FIND THE LAST EXIT!", 3.0f);
            }
        }
    }

    /* --- seleccion de items --- */
    if (in->pressed & BTN_NEXT) g->itemSel = (g->itemSel + 1) % 3;
    if (in->pressed & BTN_PREV) g->itemSel = (g->itemSel + 2) % 3;
    if (in->pressed & BTN_USE) use_item(g);

    /* --- interactuar --- */
    if (in->pressed & BTN_INTERACT) {
        int idx; TKind k = find_target(g, &idx, 10.0f);
        if (k == T_PICKUP) { g->pickupOn[idx] = 0; collect_item(g, lv->pickups[idx].type); }
        else if (k == T_NOTEBOOK) { g->nbOn[idx] = 0; g->notebooks++; mg_start(g, idx); }
        else if (k == T_DOOR) {
            const LvGroup *gr = &lv->groups[idx];
            if (gr->kind == GRP_DOOR && !g->door[idx].locked) door_open(g, idx, true);
            else if (gr->kind == GRP_DOOR) say(g, "THE DOOR IS LOCKED", 1.5f);
        }
    }

    doors_update(g, dt);

    /* --- BSODA --- */
    if (g->sprayT > 0) {
        g->sprayT -= dt; g->sprayX += g->sprayDX * 55.0f * dt; g->sprayZ += g->sprayDZ * 55.0f * dt;
        for (int n = 0; n < NPC_COUNT; n++) {
            Npc *p = &g->npc[n]; if (!p->active) continue;
            if (dist2d(p->x, p->z, g->sprayX, g->sprayZ) < 5.0f) {
                p->x += g->sprayDX * 40.0f * dt; p->z += g->sprayDZ * 40.0f * dt;
                push_out(g, &p->x, &p->z, 1.0f); if (n == NPC_BALDI) { p->plen = p->pidx = 0; p->hasDest = false; g->bCool = 0.5f; }
            }
        }
        if (!los(g, g->sprayX - g->sprayDX * 2, g->sprayZ - g->sprayDZ * 2, g->sprayX, g->sprayZ)) g->sprayT = 0;
    }
    /* --- reloj --- */
    if (g->alarmOn) { g->alarmT -= dt; if (g->alarmT <= 0) { g->alarmOn = false; hear(g, g->alarmX, g->alarmZ, 8.0f); snd_at(g, SND_BELL, g->alarmX, g->alarmZ, 200.0f); } }

    /* --- NPCs --- */
    if (g->npc[NPC_BALDI].active) baldi_update(g, dt);
    npcs_update(g, dt);
    /* NPCs no atraviesan cajas/paredes opacas fijas */
    for (int n = 1; n < NPC_COUNT; n++) if (g->npc[n].active) push_out(g, &g->npc[n].x, &g->npc[n].z, 0.8f);
}

void game_force_spoop(Game *g) { spoop_mode(g); }
