#ifndef GAME_H
#define GAME_H
#include "level.h"

enum { NPC_BALDI, NPC_PRINCIPAL, NPC_PLAYTIME, NPC_PRIZE, NPC_CRAFTERS, NPC_BULLY, NPC_SWEEP, NPC_COUNT };
enum { BTN_RUN = 1, BTN_INTERACT = 2, BTN_USE = 4, BTN_NEXT = 8, BTN_PREV = 16, BTN_PAUSE = 32,
       BTN_UP = 64, BTN_DOWN = 128, BTN_LEFT = 256, BTN_RIGHT = 512, BTN_MINUS = 1024 };
enum { MUS_NONE = 0, MUS_SCHOOL = 1, MUS_LEARN = 2 };
enum { ST_PLAYING, ST_GAMEOVER, ST_WON, ST_SECRET };

typedef struct { float fwd, strafe, turn; uint32_t held, pressed; } Input;   /* ejes -1..1 */

#define MAX_PATH 512
typedef struct {
    bool active; float x, z, yaw;
    float destx, destz; bool hasDest;
    float px[MAX_PATH], pz[MAX_PATH]; int plen, pidx; float repath;
    float vx, vz;        /* velocidad actual (para arrastres) */
    float t1, t2, t3;    /* temporizadores propios */
    int   st;
    float stun; bool vis;
} Npc;

typedef struct { float openTime, lockTime; bool open, locked, req; int silent; } DoorState;

typedef struct {
    bool active; int problem, wrong; bool impossible; double solution;
    char q[64]; char ans[12]; int alen; float endDelay; char msg[40]; uint8_t res[3];
    bool done; int audioQ[24], aqN; float aqT;
} MathGame;

#define MAX_SND 32
typedef struct {
    Level *lv;
    /* jugador */
    float x, z, y, yaw, stamina, guilt; const char *guiltType;
    bool bootsActive; float bootsTime;
    int state; float gameOverT, caughtBy;
    int notebooks, failedNotebooks; bool spoop, finale; int exitsReached;
    int item[3], itemSel;
    uint8_t pickupOn[64]; uint8_t nbOn[16]; float nbRespawn[16];
    DoorState door[MAX_GROUPS]; uint8_t entLowered[MAX_GROUPS];
    Npc npc[NPC_COUNT];
    /* baldi */
    float bTimeToMove, bBaldiWait, bAnger, bTempAnger, bMoveFrames, bCool, bPrevX, bPrevZ;
    float bPriority, bAntiTime; bool bAnti, bSees; float bFixedAcc;
    /* otros */
    int detentions; float freezeT, sweepT, hugT; float msgT; char msg[48];
    float alarmT, alarmX, alarmZ; bool alarmOn;
    float sprayT, sprayX, sprayZ, sprayDX, sprayDZ;
    float time; bool paused; MathGame mg;
    /* eventos hacia la plataforma */
    int snd[MAX_SND]; float sndVol[MAX_SND]; int nSnd; int music;
    uint32_t rng; float sndLen[64]; int lastTarget;
} Game;

void game_init(Game *g, Level *lv, uint32_t seed);
void game_update(Game *g, const Input *in, float dt);
/* Consultas para el render */
bool game_door_blocks(const Game *g, const LvSeg *s);
void game_snd(Game *g, int id, float vol);
bool game_target_name(const Game *g, char *out, int n);   /* texto de "mirando a..." */
const char *item_name(int it);
#endif
