/* Render con el GU de la PSP. Coordenadas del juego = Unity; se convierten a OpenGL
 * (mirando a -Z) en la matriz de vista, asi que los vertices se envian tal cual. */
#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspgu.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include "platform.h"

static float dist2d_s(float ax, float az, float bx, float bz) { float dx = ax - bx, dz = az - bz; return sqrtf(dx * dx + dz * dz); }

#define BUF_W 512
#define SCR_W 480
#define SCR_H 272
#define FAR_DIST 150.0f
#define MAX_VERTS (6 * 4096)

typedef struct { float u, v; float x, y, z; } V3;
typedef struct { float u, v; unsigned int c; float x, y, z; } V2;

static unsigned int __attribute__((aligned(16))) list[262144];
static V3 __attribute__((aligned(16))) vbuf[MAX_VERTS];
static V2 __attribute__((aligned(16))) hbuf[4096];
static int hn;
static Level *L; static TexPack *SP;
static int *runStart, *runEnd;     /* por textura: rango en quads estaticos ordenados */
static int curTex = -1; static const TexPack *curPack = NULL;

#define VT3 (GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_3D)
#define VT2 (GU_TEXTURE_32BITF | GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D)

static void bind_tex(const TexPack *tp, int id) {
    if (curTex == id && curPack == tp) return;
    curTex = id; curPack = tp;
    const TexEntry *e = &tp->e[id];
    sceGuTexMode(e->fmt, 0, 0, 0);
    sceGuTexImage(0, e->w, e->h, e->w, tp->base + e->off);
}

bool render_init(Level *lv, TexPack *sprites) {
    L = lv; SP = sprites;
    runStart = (int *)malloc(sizeof(int) * (lv->nTex + 1)); runEnd = (int *)malloc(sizeof(int) * (lv->nTex + 1));
    for (int t = 0; t < lv->nTex; t++) runStart[t] = runEnd[t] = 0;
    int cur = -1;
    for (int i = 0; i < lv->nQuads; i++) {
        int t = lv->quads[i].tex; if (t == 0xFFFF) continue;
        if (t != cur) { cur = t; runStart[t] = i; }
        runEnd[t] = i + 1;
    }
    sceKernelDcacheWritebackAll();   /* texturas y nivel cargados con fread: volcar a RAM para el GE */
    sceGuInit();
    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_8888, (void *)0, BUF_W);
    sceGuDispBuffer(SCR_W, SCR_H, (void *)0x88000, BUF_W);
    sceGuDepthBuffer((void *)0x110000, BUF_W);
    sceGuOffset(2048 - (SCR_W / 2), 2048 - (SCR_H / 2));
    sceGuViewport(2048, 2048, SCR_W, SCR_H);
    sceGuDepthRange(0xc350, 0x2710);
    sceGuScissor(0, 0, SCR_W, SCR_H); sceGuEnable(GU_SCISSOR_TEST);
    sceGuDepthFunc(GU_GEQUAL); sceGuEnable(GU_DEPTH_TEST);
    sceGuFrontFace(GU_CW); sceGuShadeModel(GU_SMOOTH);
    sceGuDisable(GU_CULL_FACE);            /* los quads de Unity se ven por una cara; sin cull no hay que cuidar el orden */
    sceGuEnable(GU_TEXTURE_2D); sceGuEnable(GU_CLIP_PLANES);
    sceGuTexFilter(GU_NEAREST, GU_NEAREST); sceGuTexWrap(GU_REPEAT, GU_REPEAT);
    sceGuAlphaFunc(GU_GREATER, 0x40, 0xff);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
    sceGuFinish(); sceGuSync(0, 0);
    sceDisplayWaitVblankStart(); sceGuDisplay(GU_TRUE);
    return true;
}

/* ---------------------------------------------------------------- 2D */
static void hud_begin(void) { hn = 0; }
static void quad2d(float x, float y, float w, float h, float u0, float v0, float u1, float v1, unsigned int col) {
    if (hn + 2 > 4096) return;
    V2 *a = &hbuf[hn++], *b = &hbuf[hn++];
    a->u = u0; a->v = v0; a->c = col; a->x = x; a->y = y; a->z = 0;
    b->u = u1; b->v = v1; b->c = col; b->x = x + w; b->y = y + h; b->z = 0;
}
static void flush2d(const TexPack *tp, int id) {
    if (!hn) return;
    sceKernelDcacheWritebackRange(hbuf, sizeof(V2) * hn);
    bind_tex(tp, id);
    sceGuDrawArray(GU_SPRITES, VT2, hn, 0, hbuf); hn = 0;
}
#define RGBA(r, g, b, a) (((a) << 24) | ((b) << 16) | ((g) << 8) | (r))
static void rect(float x, float y, float w, float h, unsigned int col) {
    hn = 0; quad2d(x, y, w, h, 0, 0, 1, 1, col); flush2d(SP, SPR_WHITE);
}
static void text(float x, float y, float s, unsigned int col, const char *str) {
    hn = 0;
    for (; *str; str++) {
        int c = (unsigned char)*str; if (c < 32 || c > 127) c = '?';
        int k = c - 32, cx = (k % 16) * 8, cy = (k / 16) * 16;
        quad2d(x, y, 8 * s, 16 * s, cx / 128.0f, cy / 128.0f, (cx + 8) / 128.0f, (cy + 16) / 128.0f, col);
        x += 8 * s * 0.85f;
        if (hn >= 4094) flush2d(SP, SPR_FONT);
    }
    flush2d(SP, SPR_FONT);
}
static float text_w(float s, const char *str) { return (float)strlen(str) * 8 * s * 0.85f; }
static void text_center(float y, float s, unsigned int col, const char *str) { text((SCR_W - text_w(s, str)) / 2, y, s, col, str); }
static void shadowed(float x, float y, float s, unsigned int col, const char *str) { text(x + 1, y + 1, s, RGBA(0, 0, 0, 255), str); text(x, y, s, col, str); }
static void icon(int spr, float x, float y, float w, float h) { hn = 0; quad2d(x, y, w, h, 0, 0, 1, 1, 0xFFFFFFFF); flush2d(SP, spr); }

static void begin_2d(void) {
    sceGuDisable(GU_DEPTH_TEST); sceGuDisable(GU_FOG); sceGuEnable(GU_BLEND); sceGuDisable(GU_ALPHA_TEST);
    sceGuTexFunc(GU_TFX_MODULATE, GU_TCC_RGBA); sceGuTexWrap(GU_CLAMP, GU_CLAMP); sceGuTexFilter(GU_LINEAR, GU_LINEAR);
    curTex = -1;
}
static void begin_3d(void) {
    sceGuEnable(GU_DEPTH_TEST); sceGuDisable(GU_BLEND); sceGuEnable(GU_ALPHA_TEST);
    sceGuTexFunc(GU_TFX_REPLACE, GU_TCC_RGBA); sceGuTexWrap(GU_REPEAT, GU_REPEAT); sceGuTexFilter(GU_NEAREST, GU_NEAREST);
    curTex = -1;
}

/* ---------------------------------------------------------------- 3D */
static void set_camera(const Game *g) {
    float c = cosf(g->yaw), s = sinf(g->yaw);
    float view[16] = {c, 0, -s, 0,   0, 1, 0, 0,   -s, 0, -c, 0,
                      -(c * g->x - s * g->z), -g->y, (s * g->x + c * g->z), 1};
    float n = 0.5f, f = 400.0f, fov = 1.15f, asp = (float)SCR_W / SCR_H, cot = 1.0f / tanf(fov / 2);
    float proj[16] = {cot / asp, 0, 0, 0,   0, cot, 0, 0,   0, 0, (f + n) / (n - f), -1,   0, 0, 2 * f * n / (n - f), 0};
    float model[16] = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
    sceGuSetMatrix(GU_PROJECTION, (ScePspFMatrix4 *)proj);
    sceGuSetMatrix(GU_VIEW, (ScePspFMatrix4 *)view);
    sceGuSetMatrix(GU_MODEL, (ScePspFMatrix4 *)model);
}
static int visible(const Game *g, float cx, float cz, float r, float fx, float fz) {
    float dx = cx - g->x, dz = cz - g->z; float depth = dx * fx + dz * fz;
    if (depth < -r) return 0;
    float d2 = dx * dx + dz * dz; float lim = FAR_DIST + r; if (d2 > lim * lim) return 0;
    float lat = fabsf(dx * fz - dz * fx);
    return lat <= (depth + r) * 1.45f + r;
}
static void put_quad(V3 *v, const LvQuad *q, float yoff) {
    static const int idx[6] = {0, 1, 2, 0, 2, 3};
    for (int i = 0; i < 6; i++) {
        int k = idx[i]; v[i].u = q->uv[k][0]; v[i].v = q->uv[k][1];
        v[i].x = q->p[k][0]; v[i].y = q->p[k][1] + yoff; v[i].z = q->p[k][2];
    }
}
static void draw_world(const Game *g) {
    float fx = sinf(g->yaw), fz = cosf(g->yaw); int nv = 0;
    sceGuFog(60.0f, FAR_DIST, 0xFF202020); sceGuEnable(GU_FOG);
    /* estaticos agrupados por textura */
    for (int t = 0; t < L->nTex; t++) {
        int a = runStart[t], b = runEnd[t]; if (b <= a) continue;
        int start = nv;
        for (int i = a; i < b && nv + 6 <= MAX_VERTS; i++) {
            if (!visible(g, L->qcx[i], L->qcz[i], L->qr[i], fx, fz)) continue;
            put_quad(&vbuf[nv], &L->quads[i], 0); nv += 6;
        }
        if (nv > start) {
            sceKernelDcacheWritebackRange(&vbuf[start], sizeof(V3) * (nv - start));
            bind_tex(&L->tex, t); sceGuDrawArray(GU_TRIANGLES, VT3, nv - start, 0, &vbuf[start]);
        }
    }
    /* dinamicos (puertas / entradas): textura segun estado */
    for (int i = 0; i < L->nDQuads; i++) {
        const LvQuad *q = &L->dquads[i]; int gi = q->grp; if (gi >= L->nGroups) continue;
        const LvGroup *gr = &L->groups[gi]; float yoff = 0; int tex = q->tex;
        if (gr->kind == GRP_ENTRANCE) yoff = g->entLowered[gi] ? -10.0f : 0.0f;
        else {
            const DoorState *d = &g->door[gi];
            if (gr->kind == GRP_SWING) { if (d->locked && q->texlock != 0xFFFF) tex = q->texlock; else if (d->open && q->texalt != 0xFFFF) tex = q->texalt; }
            else if (d->open && q->texalt != 0xFFFF) tex = q->texalt;
        }
        if (tex == 0xFFFF || tex >= L->nTex) continue;
        float cx = (q->p[0][0] + q->p[2][0]) * 0.5f, cz = (q->p[0][2] + q->p[2][2]) * 0.5f;
        if (!visible(g, cx, cz, 6.0f, fx, fz) || nv + 6 > MAX_VERTS) continue;
        put_quad(&vbuf[nv], q, yoff);
        sceKernelDcacheWritebackRange(&vbuf[nv], sizeof(V3) * 6);
        bind_tex(&L->tex, tex); sceGuDrawArray(GU_TRIANGLES, VT3, 6, 0, &vbuf[nv]); nv += 6;
    }
    sceGuDisable(GU_FOG);
    /* sprites (billboards) */
    float rx = cosf(g->yaw), rz = -sinf(g->yaw);
    #define BILL(spr, X, Y, Z, W, H) do { \
        if (nv + 6 <= MAX_VERTS) { \
            float hw = (W) * 0.5f; V3 *v = &vbuf[nv]; \
            float x0 = (X) - rx * hw, z0 = (Z) - rz * hw, x1 = (X) + rx * hw, z1 = (Z) + rz * hw; \
            v[0] = (V3){0, 1, x0, (Y), z0};     v[1] = (V3){1, 1, x1, (Y), z1};     v[2] = (V3){1, 0, x1, (Y) + (H), z1}; \
            v[3] = (V3){0, 1, x0, (Y), z0};     v[4] = (V3){1, 0, x1, (Y) + (H), z1}; v[5] = (V3){0, 0, x0, (Y) + (H), z0}; \
            sceKernelDcacheWritebackRange(v, sizeof(V3) * 6); bind_tex(SP, (spr)); \
            sceGuDrawArray(GU_TRIANGLES, VT3, 6, 0, v); nv += 6; } } while (0)
    static const int itemSpr[12] = {0, SPR_ITEM_ZESTY, SPR_ITEM_LOCK, SPR_ITEM_KEY, SPR_ITEM_BSODA, SPR_ITEM_QUARTER, SPR_ITEM_TAPE,
                                    SPR_ITEM_ALARM, SPR_ITEM_WD3D, SPR_ITEM_SCISSORS, SPR_ITEM_BOOTS, SPR_ITEM_TELEPORT};
    static const int nbSpr[3] = {SPR_NB_YELLOW, SPR_NB_GREEN, SPR_NB_SALMON};
    for (int i = 0; i < L->nPickups && i < 64; i++) if (g->pickupOn[i]) {
        const LvPickup *p = &L->pickups[i]; int sp = itemSpr[p->type < 12 ? p->type : 0];
        float bob = sinf(g->time * 2 + i) * 0.3f;
        if (dist2d_s(p->x, p->z, g->x, g->z) < 120) BILL(sp, p->x, p->y - 1.2f + bob, p->z, sprite_world_size[sp][0], sprite_world_size[sp][1]);
    }
    for (int i = 0; i < L->nNotebooks && i < 16; i++) if (g->nbOn[i]) {
        const LvVec3 *p = &L->notebooks[i]; int sp = nbSpr[i % 3];
        if (dist2d_s(p->x, p->z, g->x, g->z) < 120) BILL(sp, p->x, p->y - 0.8f + sinf(g->time * 2 + i) * 0.3f, p->z, sprite_world_size[sp][0], sprite_world_size[sp][1]);
    }
    static const int npcSpr[NPC_COUNT] = {SPR_BALDI, SPR_PRINCIPAL, SPR_PLAYTIME, SPR_PRIZE, SPR_CRAFTERS, SPR_BULLY, SPR_SWEEP};
    for (int n = 0; n < NPC_COUNT; n++) {
        const Npc *p = &g->npc[n]; if (!p->active) continue;
        int sp = npcSpr[n];
        if (n == NPC_BALDI && g->bMoveFrames > 0) sp = SPR_BALDI_SLAP;
        if (n == NPC_CRAFTERS && g->notebooks < 7 && dist2d_s(p->x, p->z, g->x, g->z) < 60) continue;
        float y = (n == NPC_PRIZE) ? 0.5f : 0.0f;
        BILL(sp, p->x, y, p->z, sprite_world_size[sp][0], sprite_world_size[sp][1]);
    }
    if (g->sprayT > 0) { int sp = SPR_ITEM_BSODA; BILL(sp, g->sprayX, 3.0f, g->sprayZ, 3.0f, 3.0f); }
    if (g->alarmOn) { int sp = SPR_ITEM_ALARM; BILL(sp, g->alarmX, 0.2f, g->alarmZ, 2.0f, 2.0f); }
}

/* ---------------------------------------------------------------- HUD */
static void draw_hud(const Game *g) {
    char b[96];
    /* cuadernos */
    snprintf(b, sizeof b, "%d/7 Notebooks", g->notebooks);
    rect(6, 6, text_w(1.0f, b) + 10, 22, RGBA(0, 0, 0, 150)); shadowed(10, 8, 1.0f, RGBA(255, 255, 255, 255), b);
    /* estamina */
    float st = g->stamina; if (st < 0) st = 0; float f = st / 100.0f; if (f > 1) f = 1;
    rect(6, SCR_H - 22, 104, 14, RGBA(0, 0, 0, 170));
    rect(8, SCR_H - 20, 100 * f, 10, g->stamina <= 0 ? RGBA(230, 40, 40, 255) : (st > 100 ? RGBA(255, 220, 40, 255) : RGBA(60, 200, 60, 255)));
    if (g->stamina < 0) shadowed(8, SCR_H - 40, 0.9f, RGBA(255, 60, 60, 255), "OUT OF STAMINA");
    /* items */
    for (int i = 0; i < 3; i++) {
        float x = SCR_W - 3 * 46 - 4 + i * 46, y = SCR_H - 46;
        rect(x - 2, y - 2, 44, 44, i == g->itemSel ? RGBA(230, 40, 40, 230) : RGBA(0, 0, 0, 150));
        rect(x, y, 40, 40, RGBA(60, 60, 60, 200));
        if (g->item[i]) {
            static const int sp[12] = {0, SPR_ITEM_ZESTY, SPR_ITEM_LOCK, SPR_ITEM_KEY, SPR_ITEM_BSODA, SPR_ITEM_QUARTER, SPR_ITEM_TAPE,
                                       SPR_ITEM_ALARM, SPR_ITEM_WD3D, SPR_ITEM_SCISSORS, SPR_ITEM_BOOTS, SPR_ITEM_TELEPORT};
            icon(sp[g->item[i]], x + 2, y + 2, 36, 36);
        }
    }
    const char *nm = item_name(g->item[g->itemSel]);
    text(SCR_W - text_w(0.8f, nm) - 6, SCR_H - 64, 0.8f, RGBA(255, 255, 255, 255), nm);
    /* mira + objetivo */
    rect(SCR_W / 2 - 1, SCR_H / 2 - 5, 2, 10, RGBA(255, 255, 255, 160)); rect(SCR_W / 2 - 5, SCR_H / 2 - 1, 10, 2, RGBA(255, 255, 255, 160));
    char tg[48]; if (game_target_name(g, tg, sizeof tg)) { text_center(SCR_H / 2 + 12, 0.8f, RGBA(255, 255, 160, 230), tg); }
    if (g->msgT > 0) { rect(0, 40, SCR_W, 24, RGBA(0, 0, 0, 150)); text_center(44, 1.0f, RGBA(255, 230, 80, 255), g->msg); }
    if (g->freezeT > 0) text_center(80, 1.0f, RGBA(255, 120, 200, 255), "PLAYTIME HAS YOU! (SQUARE with scissors)");
    if (g->bootsActive) shadowed(6, 32, 0.8f, RGBA(200, 200, 255, 255), "BIG BOOTS");
    if (g->bAnti) shadowed(6, 44, 0.8f, RGBA(120, 255, 120, 255), "BALDI CAN'T HEAR");
}
static void draw_math(const Game *g) {
    const MathGame *m = &g->mg;
    rect(0, 0, SCR_W, SCR_H, RGBA(20, 60, 120, 235));
    rect(40, 40, 400, 190, RGBA(240, 240, 220, 255));
    for (int i = 0; i < 3; i++) {
        unsigned int col = m->res[i] == 1 ? RGBA(40, 180, 40, 255) : (m->res[i] == 2 ? RGBA(220, 40, 40, 255) : RGBA(160, 160, 160, 255));
        rect(60 + i * 34, 50, 28, 28, col);
    }
    text(60, 20, 0.9f, RGBA(255, 255, 255, 255), "BALDI'S BASICS IN EDUCATION AND LEARNING");
    if (m->problem <= 3) {
        text(60, 100, 1.5f, RGBA(0, 0, 0, 255), m->q);
        char a[24]; snprintf(a, sizeof a, "%s%s", m->ans, ((int)(g->time * 2) & 1) ? "_" : " ");
        rect(60, 140, 360, 36, RGBA(255, 255, 255, 255)); text(66, 144, 1.5f, RGBA(0, 0, 160, 255), a);
        text(60, 190, 0.8f, RGBA(60, 60, 60, 255), "D-pad UP/DOWN: digit  RIGHT: next digit  LEFT: erase");
        text(60, 206, 0.8f, RGBA(60, 60, 60, 255), "TRIANGLE: +/-    CROSS: OK");
    } else text_center(120, 1.1f, RGBA(180, 0, 0, 255), m->msg);
}

/* ---------------------------------------------------------------- pantallas */
void render_title(float t) {
    sceGuStart(GU_DIRECT, list);
    sceGuClearColor(0xFFE0A050); sceGuClearDepth(0); sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);
    begin_2d();
    icon(SPR_BALDI, 20, 20 + sinf(t * 3) * 3, 100, 230);
    icon(SPR_PRINCIPAL, SCR_W - 120, 30, 90, 200);
    text_center(18, 2.0f, RGBA(255, 255, 255, 255), "BALDI'S BASICS");
    text_center(52, 1.2f, RGBA(255, 255, 160, 255), "in Education and Learning  -  PSP");
    text_center(100, 0.9f, RGBA(0, 0, 0, 255), "Collect 7 notebooks and escape the school.");
    text_center(118, 0.9f, RGBA(0, 0, 0, 255), "Get 3 problems right... or else.");
    text(150, 150, 0.8f, RGBA(0, 0, 0, 255), "Analog: walk / turn     L / R: strafe");
    text(150, 166, 0.8f, RGBA(0, 0, 0, 255), "CROSS: open / take      SQUARE: use item");
    text(150, 182, 0.8f, RGBA(0, 0, 0, 255), "CIRCLE (hold): run      D-pad L/R: select item");
    if (((int)(t * 2)) & 1) text_center(224, 1.3f, RGBA(255, 255, 255, 255), "Press START");
    sceGuFinish(); sceGuSync(0, 0); sceDisplayWaitVblankStart(); sceGuSwapBuffers();
}

void render_game(const Game *g) {
    sceGuStart(GU_DIRECT, list);
    if (g->state == ST_GAMEOVER) {
        sceGuClearColor(0xFF000000); sceGuClearDepth(0); sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);
        begin_2d();
        float sh = g->gameOverT < 2.5f ? sinf(g->gameOverT * 80) * 6 : 0, sc = 1.0f + (g->gameOverT < 0.4f ? g->gameOverT * 1.5f : 0.6f);
        icon(SPR_BALDI, SCR_W / 2 - 60 * sc + sh, SCR_H / 2 - 135 * sc, 120 * sc, 270 * sc);
        if (g->gameOverT > 2.5f) { text_center(230, 1.2f, RGBA(255, 255, 255, 255), "Press START to try again"); }
        sceGuFinish(); sceGuSync(0, 0); sceDisplayWaitVblankStart(); sceGuSwapBuffers(); return;
    }
    if (g->state == ST_WON || g->state == ST_SECRET) {
        sceGuClearColor(0xFF60C060); sceGuClearDepth(0); sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);
        begin_2d();
        icon(g->state == ST_SECRET ? SPR_FACE : SPR_BALDI, SCR_W / 2 - 50, 40, 100, 200);
        text_center(10, 1.6f, RGBA(255, 255, 255, 255), g->state == ST_SECRET ? "...YOU FOUND THE SECRET?" : "YOU ESCAPED!");
        if (g->gameOverT > 1.5f) text_center(240, 1.0f, RGBA(255, 255, 255, 255), "Press START");
        sceGuFinish(); sceGuSync(0, 0); sceDisplayWaitVblankStart(); sceGuSwapBuffers(); return;
    }
    unsigned int sky = g->spoop ? 0xFF100808 : 0xFF303030;
    sceGuClearColor(sky); sceGuClearDepth(0); sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);
    set_camera(g); begin_3d(); draw_world(g);
    begin_2d();
    if (g->mg.active) draw_math(g); else draw_hud(g);
    if (g->paused) { rect(0, 0, SCR_W, SCR_H, RGBA(0, 0, 0, 160)); text_center(110, 2.0f, RGBA(255, 255, 255, 255), "PAUSED"); text_center(150, 0.9f, RGBA(220, 220, 220, 255), "START: resume"); }
    sceGuFinish(); sceGuSync(0, 0); sceDisplayWaitVblankStart(); sceGuSwapBuffers();
}
