/* Mezclador de audio: voces mono 22050 Hz -> salida estereo 44100 Hz en un hilo. */
#include <pspkernel.h>
#include <pspaudio.h>
#include <string.h>
#include <stdlib.h>
#include "platform.h"

#define NVOICE 12
#define BLOCK 1024
typedef struct { volatile int active; const int16_t *data; uint32_t n; float pos; float vol; } Voice;

static Voice voice[NVOICE]; static Voice music;
static const SoundPack *SPK; static int chan = -1; static volatile int running;
static int16_t __attribute__((aligned(64))) outbuf[2][BLOCK * 2];

static int audio_thread(SceSize args, void *argp) {
    int cur = 0;
    while (running) {
        int16_t *o = outbuf[cur]; cur ^= 1;
        for (int i = 0; i < BLOCK; i++) {
            float acc = 0;
            for (int v = 0; v < NVOICE; v++) {
                Voice *vo = &voice[v]; if (!vo->active) continue;
                uint32_t p = (uint32_t)vo->pos; if (p >= vo->n) { vo->active = 0; continue; }
                acc += vo->data[p] * vo->vol; vo->pos += 0.5f;
            }
            if (music.active) {
                uint32_t p = (uint32_t)music.pos; if (p >= music.n) { music.pos = 0; p = 0; }
                acc += music.data[p] * music.vol; music.pos += 0.5f;
            }
            if (acc > 32767) acc = 32767; if (acc < -32768) acc = -32768;
            o[i * 2] = o[i * 2 + 1] = (int16_t)acc;
        }
        sceAudioOutputBlocking(chan, PSP_AUDIO_VOLUME_MAX, o);
    }
    return 0;
}

bool audio_init(const SoundPack *sp) {
    SPK = sp;
    chan = sceAudioChReserve(PSP_AUDIO_NEXT_CHANNEL, BLOCK, PSP_AUDIO_FORMAT_STEREO);
    if (chan < 0) return false;
    running = 1;
    int th = sceKernelCreateThread("audio", audio_thread, 0x12, 0x10000, 0, NULL);
    if (th < 0) return false;
    sceKernelStartThread(th, 0, NULL);
    return true;
}
void audio_play(int id, float vol) {
    if (!SPK || id < 0 || id >= SPK->count || SPK->n[id] == 0) return;
    int best = -1;
    for (int i = 0; i < NVOICE; i++) if (!voice[i].active) { best = i; break; }
    if (best < 0) best = 0;
    Voice *v = &voice[best]; v->active = 0; v->data = sound_data(SPK, id); v->n = SPK->n[id]; v->pos = 0; v->vol = vol; v->active = 1;
}
void audio_music(int id, float vol) {
    music.active = 0;
    if (!SPK || id < 0 || id >= SPK->count || SPK->n[id] == 0) return;
    music.data = sound_data(SPK, id); music.n = SPK->n[id]; music.pos = 0; music.vol = vol; music.active = 1;
}
void audio_shutdown(void) { running = 0; sceKernelDelayThread(100000); if (chan >= 0) sceAudioChRelease(chan); }
