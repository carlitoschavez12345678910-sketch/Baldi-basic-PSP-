#!/usr/bin/env python3
"""Render de prueba en primera persona leyendo level.bin + textures.bin (valida formato)."""
import sys, struct, math, numpy as np
from PIL import Image
d = open(sys.argv[1]+'/level.bin','rb').read()
tb = open(sys.argv[1]+'/textures.bin','rb').read()
assert d[:4]==b'BLVL' and tb[:4]==b'BTEX'
spawn = struct.unpack_from('<3f', d, 8)
cnt = struct.unpack_from('<16I', d, 24); offs = struct.unpack_from('<16I', d, 88)
nq, ndq = cnt[0], cnt[1]
def quads(off, n):
    out=[]
    for i in range(n):
        v=struct.unpack_from('<12f8f4H', d, off+i*88)
        out.append((np.array(v[0:12]).reshape(4,3), np.array(v[12:20]).reshape(4,2), v[20:24]))
    return out
Q = quads(offs[0], nq) + quads(offs[1], ndq)
nt = struct.unpack_from('<I', tb, 4)[0]
texs=[]
for i in range(nt):
    w,h,fmt,off,sz = struct.unpack_from('<HHIII', tb, 8+i*16)
    px = np.frombuffer(tb, '<u2', w*h, off).reshape(h,w).astype(np.uint32)
    if fmt==0: r=(px&31)<<3; g=((px>>5)&63)<<2; b=((px>>11)&31)<<3; a=np.full_like(px,255)
    elif fmt==1: r=(px&31)<<3; g=((px>>5)&31)<<3; b=((px>>10)&31)<<3; a=np.where(px>>15,255,0)
    else: r=(px&15)<<4; g=((px>>4)&15)<<4; b=((px>>8)&15)<<4; a=((px>>12)&15)<<4
    texs.append(np.stack([r,g,b,a],-1).astype(np.uint8))
def render(pos, yaw_deg, W=480, H=272, fov=70, name='fp.png'):
    yaw=math.radians(yaw_deg); fx=math.sin(yaw), math.cos(yaw)    # Unity: yaw 0 mira +Z
    f=1/math.tan(math.radians(fov)/2)*H/2*0+ (W/2)/math.tan(math.radians(fov)/2)
    img=np.zeros((H,W,3),np.float32); img[:]=(25,25,40); zb=np.full((H,W),1e9,np.float32)
    def tocam(p):
        dx,dy,dz=p[0]-pos[0],p[1]-pos[1],p[2]-pos[2]
        cx=dx*math.cos(yaw)-dz*math.sin(yaw); cz=dx*math.sin(yaw)+dz*math.cos(yaw)
        return cx,dy,cz
    for P,UV,(t,ta,tl,grp) in Q:
        if t==0xFFFF: continue
        if grp!=0xFFFF: pass
        C=[tocam(p) for p in P]
        if max(c[2] for c in C)<0.5: continue
        if min(c[2] for c in C)<0.5:  # clip burdo: descartar
            continue
        if min(math.hypot(c[0],c[2]) for c in C)>120: continue
        S=[(W/2+f*c[0]/c[2], H/2-f*c[1]/c[2], 1/c[2]) for c in C]
        for tri in ((0,1,2),(0,2,3)):
            xs=[S[i][0] for i in tri]; ys=[S[i][1] for i in tri]
            x0,x1=int(max(0,min(xs))),int(min(W-1,max(xs))); y0,y1=int(max(0,min(ys))),int(min(H-1,max(ys)))
            if x1<x0 or y1<y0: continue
            (ax,ay,aw),(bx,by,bw),(cx_,cy,cw)=[S[i] for i in tri]
            den=(by-cy)*(ax-cx_)+(cx_-bx)*(ay-cy)
            if abs(den)<1e-9: continue
            gx,gy=np.meshgrid(np.arange(x0,x1+1)+.5,np.arange(y0,y1+1)+.5)
            l1=((by-cy)*(gx-cx_)+(cx_-bx)*(gy-cy))/den; l2=((cy-ay)*(gx-cx_)+(ax-cx_)*(gy-cy))/den; l3=1-l1-l2
            m=(l1>=0)&(l2>=0)&(l3>=0)
            if not m.any(): continue
            w=l1*aw+l2*bw+l3*cw
            u=(l1*aw*UV[tri[0]][0]+l2*bw*UV[tri[1]][0]+l3*cw*UV[tri[2]][0])/w
            v=(l1*aw*UV[tri[0]][1]+l2*bw*UV[tri[1]][1]+l3*cw*UV[tri[2]][1])/w
            depth=1/w
            T=texs[t]; th,tw=T.shape[:2]
            tx=(np.floor(u*tw).astype(int))%tw; ty=(np.floor(v*th).astype(int))%th
            col=T[ty,tx]
            sub=zb[y0:y1+1,x0:x1+1]
            ok=m&(depth<sub)&(col[...,3]>128)
            sub[ok]=depth[ok]
            fog=np.clip(1-depth/120,0.15,1)[...,None]
            tile=img[y0:y1+1,x0:x1+1]
            tile[ok]=(col[...,:3]*fog)[ok]
    Image.fromarray(img.astype(np.uint8)).resize((W*2,H*2),Image.NEAREST).save(name)
views=[((5,4,5),0),((5,4,60),0),((-40,4,30),90),((5,4,125),180)]
for i,(p,y) in enumerate(views):
    render(p,y,name=f'{sys.argv[1]}/fp{i}.png'); print('ok',i)
