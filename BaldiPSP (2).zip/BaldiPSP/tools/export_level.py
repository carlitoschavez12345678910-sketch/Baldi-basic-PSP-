#!/usr/bin/env python3
"""
Exporta School.unity (Baldi's Basics Classic 1.4.3, Unity 2018) a un binario
compacto para el port a PSP.

Uso:  python3 export_level.py <ruta_proyecto_unity> <dir_salida>

Genera:
  level.bin   geometria, colisiones, entidades, rejilla de navegacion
  textures.bin  texturas ya convertidas a 16 bits potencia de 2 (formato PSP)
  preview.png   vista cenital para comprobar la exportacion
"""
import sys, os, re, struct, math, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unity_scene import *
from PIL import Image, ImageDraw

BUILTIN = '0000000000000000e000000000000000'
MAX_TEX = 128          # lado maximo de textura en la PSP (RAM justa)
NAV_CELL = 2.5

# ---------------------------------------------------------------- utilidades
def mat_tex_info(mat_path_cache, g2p, guid):
    """devuelve dict(tex_guid, scale, offset) de un material por guid."""
    if guid in mat_path_cache: return mat_path_cache[guid]
    info = None
    p = g2p.get(guid)
    if p and p.endswith('.mat'):
        objs = load_scene(p)
        for fid, (c, k, v) in objs.items():
            if c != 21: continue
            for env in v['m_SavedProperties']['m_TexEnvs']:
                if '_MainTex' in env:
                    e = env['_MainTex']
                    tg = e['m_Texture'].get('guid')
                    info = dict(tex=tg, scale=(e['m_Scale']['x'], e['m_Scale']['y']),
                                offset=(e['m_Offset']['x'], e['m_Offset']['y']),
                                name=v.get('m_Name', ''))
    mat_path_cache[guid] = info
    return info

class TexTable:
    def __init__(self, g2p):
        self.g2p = g2p; self.ids = {}; self.order = []; self.alpha = {}
    def get(self, tguid):
        if not tguid or tguid not in self.g2p: return 0xFFFF
        if tguid not in self.ids:
            self.ids[tguid] = len(self.order); self.order.append(tguid)
        return self.ids[tguid]

def mesh_aabb(path_cache, g2p, guid):
    if guid in path_cache: return path_cache[guid]
    p = g2p.get(guid); res = None
    if p and os.path.exists(p):
        s = open(p, encoding='utf-8-sig', errors='ignore').read()
        m = re.search(r'm_LocalAABB:\s*\n\s*m_Center: \{x: ([-\d.e+]+), y: ([-\d.e+]+), z: ([-\d.e+]+)\}\s*\n\s*m_Extent: \{x: ([-\d.e+]+), y: ([-\d.e+]+), z: ([-\d.e+]+)\}', s)
        if m:
            v = [float(x) for x in m.groups()]
            res = (v[0:3], v[3:6])
    path_cache[guid] = res
    return res

def quad_corners(M):
    # Quad de Unity: front -Z, uv (0,0) en (+.5,-.5)
    pts = [(0.5, -0.5, 0), (-0.5, -0.5, 0), (-0.5, 0.5, 0), (0.5, 0.5, 0)]
    uvs = [(0, 0), (1, 0), (1, 1), (0, 1)]
    return [xform(M, p) for p in pts], uvs

def box_faces(M, center, ext, skip_bottom=True):
    """caras de una caja orientada. devuelve lista de (4 puntos, 4 uv)."""
    cx, cy, cz = center; ex, ey, ez = ext
    def P(sx, sy, sz): return xform(M, (cx+sx*ex, cy+sy*ey, cz+sz*ez))
    faces = [
        ([P(-1, -1, -1), P(1, -1, -1), P(1, 1, -1), P(-1, 1, -1)]),
        ([P(1, -1, 1), P(-1, -1, 1), P(-1, 1, 1), P(1, 1, 1)]),
        ([P(-1, -1, 1), P(-1, -1, -1), P(-1, 1, -1), P(-1, 1, 1)]),
        ([P(1, -1, -1), P(1, -1, 1), P(1, 1, 1), P(1, 1, -1)]),
        ([P(-1, 1, -1), P(1, 1, -1), P(1, 1, 1), P(-1, 1, 1)]),
    ]
    if not skip_bottom:
        faces.append([P(-1, -1, 1), P(1, -1, 1), P(1, -1, -1), P(-1, -1, -1)])
    uvs = [(0, 0), (1, 0), (1, 1), (0, 1)]
    return [(f, uvs) for f in faces]

def is_descendant(S, g, anc):
    n = 0
    while g and n < 80:
        if g == anc: return True
        tf = S.go_tf.get(g)
        par = S.tf[tf]['m_Father']['fileID'] if tf in S.tf else 0
        g = S.tf[par]['m_GameObject']['fileID'] if par in S.tf else 0
        n += 1
    return False

# ---------------------------------------------------------------- principal
def main(proj, out):
    os.makedirs(out, exist_ok=True)
    g2p = load_guid_map(proj)
    S = Scene(os.path.join(proj, 'Assets/Scene/School.unity'))
    print('escena:', len(S.objs), 'objetos')
    def script_of(v):
        return os.path.basename(g2p.get(v['m_Script']['guid'], '?'))
    comp = lambda fid: S.objs[fid][2] if fid in S.objs else None
    go_of_comp = lambda fid: comp(fid)['m_GameObject']['fileID']
    def gpos(g):
        M = S.world(S.go_tf[g]); return [M[0][3], M[1][3], M[2][3]]

    mat_cache = {}; mesh_cache = {}
    tex = TexTable(g2p)

    # --- scripts por GO
    scripts = collections.defaultdict(list)
    for g, comps in S.comp_by_go.items():
        for f, c, k, v in comps:
            if c == 114: scripts[g].append((script_of(v), f, v))

    # --- puertas y entradas: grupos dinamicos
    groups = []              # dict(kind, goid, ...)
    quad_group = {}          # renderer fileID -> (group idx, role)
    coll_group = {}          # collider fileID -> group idx
    go_group = {}            # GO id -> group idx (entradas: toda la jerarquia)
    for g, lst in scripts.items():
        if not S.active(g): continue
        for sname, f, v in lst:
            if sname == 'DoorScript.cs' or sname == 'SwingingDoorScript.cs':
                kind = 0 if sname == 'DoorScript.cs' else 1
                gi = len(groups)
                pos = gpos(g)
                mats = {}
                for key in ('closed', 'open', 'closedOutside', 'openOutside', 'locked', 'lockedOutside'):
                    if key in v and v[key].get('guid'):
                        mats[key] = mat_tex_info(mat_cache, g2p, v[key]['guid'])
                groups.append(dict(kind=kind, go=g, pos=pos, mats=mats,
                                   dist=v.get('openingDistance', 10.0)))
                for role in ('inside', 'outside'):
                    if v.get(role, {}).get('fileID'): quad_group[v[role]['fileID']] = (gi, role)
                for key in ('barrier', 'invisibleBarrier'):
                    if v.get(key, {}).get('fileID'): coll_group[v[key]['fileID']] = gi
            if sname == 'EntranceScript.cs':
                gi = len(groups)
                groups.append(dict(kind=2, go=g, pos=gpos(g), mats={}, dist=0))
                for gg in S.go:
                    if is_descendant(S, gg, g): go_group[gg] = gi

    # --- geometria
    quads = []   # dict(p, uv, tex, alpha, grp, texalt, texlock)
    def add_quad(pts, uvs, minfo, grp=0xFFFF, texalt=0xFFFF, texlock=0xFFFF):
        if minfo is None: return
        sc, off = minfo['scale'], minfo['offset']
        uv2 = []
        for (u, vv) in uvs:
            uu = u*sc[0] + off[0]; v2 = vv*sc[1] + off[1]
            uv2.append((uu, 1.0 - v2))
        quads.append(dict(p=pts, uv=uv2, tex=tex.get(minfo['tex']), grp=grp,
                          texalt=texalt, texlock=texlock))

    segs = []    # dict(x1,z1,x2,z2,y0,y1,grp)
    boxes_trig = []
    def add_wall_seg(pts, grp, strict=True, ignore_y=False):
        ys = [p[1] for p in pts]
        y0, y1 = min(ys), max(ys)
        # par de vertices mas separados en XZ
        best = None
        for i in range(4):
            for j in range(i+1, 4):
                d = (pts[i][0]-pts[j][0])**2 + (pts[i][2]-pts[j][2])**2
                if best is None or d > best[0]: best = (d, i, j)
        d, i, j = best
        if d < 1e-3: return False            # horizontal
        # vertical si la altura es apreciable
        if y1 - y0 < 1.0: return False
        if not ignore_y and (y1 < 1.5 or y0 > 7.0): return False
        segs.append(dict(x1=pts[i][0], z1=pts[i][2], x2=pts[j][0], z2=pts[j][2], y0=y0, y1=y1, grp=grp))
        return True

    floor_quads = []   # para rejilla de navegacion
    n_nonquad = 0
    for g, comps in S.comp_by_go.items():
        if not S.active(g): continue
        gname = S.name(g)
        M = S.world(S.go_tf[g]) if g in S.go_tf else None
        if M is None: continue
        mf = [v for f, c, k, v in comps if c == 33]
        mr = [(f, v) for f, c, k, v in comps if c == 23]
        grp_ent = go_group.get(g, 0xFFFF)
        if mf and mr and mr[0][1].get('m_Enabled', 1):
            mesh = mf[0]['m_Mesh']
            rf, rv = mr[0]
            mats = [m.get('guid') for m in rv.get('m_Materials', [])]
            minfo = mat_tex_info(mat_cache, g2p, mats[0]) if mats and mats[0] else None
            grp = grp_ent; texalt = texlock = 0xFFFF
            if rf in quad_group:
                grp, role = quad_group[rf]
                gm = groups[grp]['mats']
                if role == 'inside':
                    closed, opn, lck = gm.get('closed'), gm.get('open'), gm.get('locked')
                else:
                    closed, opn, lck = gm.get('closedOutside'), gm.get('openOutside'), gm.get('lockedOutside')
                if closed: minfo = closed
                if opn: texalt = tex.get(opn['tex'])
                if lck: texlock = tex.get(lck['tex'])
            if mesh.get('guid') == BUILTIN and mesh.get('fileID') == 10210:
                pts, uvs = quad_corners(M)
                add_quad(pts, uvs, minfo, grp, texalt, texlock)
                if gname in ('Floor', 'Cafe_Tile') and abs(pts[0][1]) < 1.0 and abs(pts[0][1]-pts[2][1]) < 0.1:
                    floor_quads.append(pts)
            elif mesh.get('guid') == BUILTIN and mesh.get('fileID') == 10202:
                for pts, uvs in box_faces(M, (0, 0, 0), (0.5, 0.5, 0.5), skip_bottom=False):
                    add_quad(pts, uvs, minfo, grp)
            elif mesh.get('guid') == BUILTIN:
                for pts, uvs in box_faces(M, (0, 0, 0), (0.5, 0.5, 0.5)):
                    add_quad(pts, uvs, minfo, grp)
                n_nonquad += 1
            else:
                bb = mesh_aabb(mesh_cache, g2p, mesh['guid'])
                if bb:
                    for pts, uvs in box_faces(M, bb[0], bb[1]):
                        add_quad(pts, uvs, minfo, grp)
                    n_nonquad += 1
        # colisiones
        for f, c, k, v in comps:
            if c not in (64, 65): continue
            if not v.get('m_Enabled', 1) or v.get('m_IsTrigger', 0): continue
            grp = coll_group.get(f, grp_ent)
            if c == 64:
                mesh = v.get('m_Mesh', {})
                if mesh.get('guid') == BUILTIN and mesh.get('fileID') == 10210:
                    pts, _ = quad_corners(M)
                    add_wall_seg(pts, grp, ignore_y=(grp_ent != 0xFFFF and groups[grp_ent]['kind'] == 2))
            else:
                cen = v['m_Center']; sz = v['m_Size']
                c3 = (cen['x'], cen['y'], cen['z']); e3 = (sz['x']/2, sz['y']/2, sz['z']/2)
                faces = box_faces(M, c3, e3, skip_bottom=False)
                allp = [p for fc, _ in faces for p in fc]
                if (max(p[1] for p in allp) < 1.5 or min(p[1] for p in allp) > 7.5) and not (grp_ent != 0xFFFF): continue
                # contorno XZ: las 4 caras verticales
                for fc, _ in faces[:4]:
                    add_wall_seg(fc, grp, ignore_y=(grp_ent != 0xFFFF))
    print('quads:', len(quads), ' segmentos:', len(segs), ' cajas aprox:', n_nonquad, ' grupos dinamicos:', len(groups))

    # --- entidades
    pickup_types = {'Pickup_EnergyFlavoredZestyBar': 1, 'Pickup_YellowDoorLock': 2, 'Pickup_Key': 3,
                    'Pickup_BSODA': 4, 'Pickup_Quarter': 5, 'Pickup_Tape': 6, 'Pickup_AlarmClock': 7,
                    'Pickup_WD-3D': 8, 'Pickup_SafetyScissors': 9, 'Pickup_BigBoots': 10, 'Pickup_Teleporter': 11}
    pickups, notebooks, machines, npcs = [], [], [], {}
    spawn = None; waypoints = []
    triggers = []
    for g, lst in scripts.items():
        nm = S.name(g)
        for sname, f, v in lst:
            if sname == 'PickupScript.cs' and nm in pickup_types:
                pickups.append((gpos(g), pickup_types[nm], 1 if S.active(g) else 0))
            elif sname == 'NotebookScript.cs' and S.active(g):
                notebooks.append(gpos(g))
            elif sname == 'PlayerScript.cs': spawn = gpos(g)
            elif sname == 'AILocationSelectorScript.cs':
                for ref in v.get('newLocation', []):
                    tfv = comp(ref['fileID'])
                    if tfv:
                        gg = tfv['m_GameObject']['fileID']; waypoints.append(gpos(gg))
            elif sname == 'PrincipalScript.cs' and 'extra' not in npcs:
                ex = [0, 0, 0, 0, 0xFFFF]
                for i, key in enumerate(('principalDetentionPoint', 'playerDetentionPoint')):
                    r = v.get(key, {}).get('fileID')
                    if r and comp(r):
                        pp = gpos(comp(r)['m_GameObject']['fileID']); ex[i*2] = pp[0]; ex[i*2+1] = pp[2]
                r = v.get('officeDoor', {}).get('fileID')
                if r and comp(r):
                    dg = comp(r)['m_GameObject']['fileID']
                    for gi, gr in enumerate(groups):
                        if gr['go'] == dg: ex[4] = gi
                npcs['extra'] = ex
                npcs['Principal'] = gpos(g)
            elif sname in ('BaldiScript.cs', 'PrincipalScript.cs', 'PlaytimeScript.cs', 'FirstPrizeScript.cs',
                           'CraftersScript.cs', 'BullyScript.cs', 'SweepScript.cs'):
                npcs[sname.replace('Script.cs', '')] = gpos(g)
            elif sname == 'FacultyTriggerScript.cs':
                triggers.append(('faculty', g))
            elif sname == 'ExitTriggerScript.cs':
                triggers.append(('exit', g))
            elif sname == 'NearExitTriggerScript.cs':
                grpi = go_group.get(f and v.get('es', {}).get('fileID') and go_of_comp(v['es']['fileID']), None)
                triggers.append(('nearexit', g, v.get('es', {}).get('fileID')))
    for g in S.go:
        if S.name(g) in ('BSODAMachine', 'ZestyMachine', 'PayPhone', 'TapePlayer') and S.active(g):
            machines.append((S.name(g), gpos(g)))
    # trigger AABB
    trig_out = []
    ent_by_comp = {}
    for gi, gr in enumerate(groups):
        if gr['kind'] == 2: ent_by_comp[gr['go']] = gi
    for t in triggers:
        g = t[1]
        M = S.world(S.go_tf[g]); box = None
        for f, c, k, v in S.comp_by_go[g]:
            if c == 65:
                cen = v['m_Center']; sz = v['m_Size']
                pts = [xform(M, (cen['x']+sx*sz['x']/2, cen['y']+sy*sz['y']/2, cen['z']+sz_*sz['z']/2))
                       for sx in (-1, 1) for sy in (-1, 1) for sz_ in (-1, 1)]
                box = (min(p[0] for p in pts), min(p[2] for p in pts), max(p[0] for p in pts), max(p[2] for p in pts))
        if not box: continue
        kind = {'faculty': 1, 'exit': 2, 'nearexit': 3}[t[0]]
        ent = 0xFFFF
        if t[0] == 'nearexit' and t[2]:
            egg = go_of_comp(t[2]); ent = ent_by_comp.get(egg, 0xFFFF)
        trig_out.append((kind, box, ent))
    print('pickups', len(pickups), 'cuadernos', len(notebooks), 'waypoints', len(waypoints),
          'triggers', len(trig_out), 'npcs', list(npcs))

    # --- rejilla de navegacion
    xs = [p[0] for q in quads for p in q['p']]; zs = [p[2] for q in quads for p in q['p']]
    gx0, gz0 = min(xs) - 5, min(zs) - 5
    gw = int(math.ceil((max(xs) + 5 - gx0) / NAV_CELL)); gh = int(math.ceil((max(zs) + 5 - gz0) / NAV_CELL))
    import numpy as np
    walk = np.zeros((gh, gw), dtype=np.uint8)
    def inside_quad(pts, x, z):
        # rect eje alineado casi siempre
        minx = min(p[0] for p in pts); maxx = max(p[0] for p in pts)
        minz = min(p[2] for p in pts); maxz = max(p[2] for p in pts)
        return minx <= x <= maxx and minz <= z <= maxz
    for pts in floor_quads:
        minx = min(p[0] for p in pts); maxx = max(p[0] for p in pts)
        minz = min(p[2] for p in pts); maxz = max(p[2] for p in pts)
        i0 = max(0, int((minx-gx0)/NAV_CELL)); i1 = min(gw-1, int((maxx-gx0)/NAV_CELL))
        j0 = max(0, int((minz-gz0)/NAV_CELL)); j1 = min(gh-1, int((maxz-gz0)/NAV_CELL))
        for j in range(j0, j1+1):
            for i in range(i0, i1+1):
                cx = gx0 + (i+0.5)*NAV_CELL; cz = gz0 + (j+0.5)*NAV_CELL
                if minx <= cx <= maxx and minz <= cz <= maxz: walk[j, i] = 1
    # quitar celdas cerca de segmentos bloqueantes (no puertas)
    R = 1.2
    blockers = [s for s in segs if s['grp'] == 0xFFFF or groups[s['grp']]['kind'] == 2]
    for s in blockers:
        minx = min(s['x1'], s['x2']) - R; maxx = max(s['x1'], s['x2']) + R
        minz = min(s['z1'], s['z2']) - R; maxz = max(s['z1'], s['z2']) + R
        i0 = max(0, int((minx-gx0)/NAV_CELL)); i1 = min(gw-1, int((maxx-gx0)/NAV_CELL))
        j0 = max(0, int((minz-gz0)/NAV_CELL)); j1 = min(gh-1, int((maxz-gz0)/NAV_CELL))
        dx, dz = s['x2']-s['x1'], s['z2']-s['z1']; L2 = dx*dx+dz*dz
        for j in range(j0, j1+1):
            for i in range(i0, i1+1):
                if not walk[j, i]: continue
                cx = gx0 + (i+0.5)*NAV_CELL; cz = gz0 + (j+0.5)*NAV_CELL
                t = 0 if L2 == 0 else max(0, min(1, ((cx-s['x1'])*dx+(cz-s['z1'])*dz)/L2))
                px, pz = s['x1']+t*dx, s['z1']+t*dz
                if (cx-px)**2 + (cz-pz)**2 < R*R: walk[j, i] = 0
    print('rejilla nav:', gw, 'x', gh, ' celdas libres:', int(walk.sum()))

    # --- texturas -> textures.bin
    tex_blobs = []
    for i, tg in enumerate(tex.order):
        im = Image.open(g2p[tg]).convert('RGBA')
        arr = np.array(im)
        a = arr[..., 3]
        has_a = (a < 250).any()
        w, h = im.size
        def p2(n):
            r = 8
            while r < n and r < MAX_TEX: r *= 2
            return r
        # potencia de 2 mas cercana, tope MAX_TEX
        def near_p2(n):
            r = 8
            while r*2 <= n*1.4 and r < MAX_TEX: r *= 2
            return min(r, MAX_TEX)
        tw, th = near_p2(w), near_p2(h)
        im2 = im.resize((tw, th), Image.BILINEAR if tw < w else Image.NEAREST)
        arr = np.array(im2).astype(np.uint32)
        r, g, b, a = arr[..., 0], arr[..., 1], arr[..., 2], arr[..., 3]
        if has_a:
            binary = ((a == 0) | (a == 255)).mean() > 0.9
            if binary:
                fmt = 1  # 5551
                px = (r >> 3) | ((g >> 3) << 5) | ((b >> 3) << 10) | ((a >= 128).astype(np.uint32) << 15)
            else:
                fmt = 2  # 4444
                px = (r >> 4) | ((g >> 4) << 4) | ((b >> 4) << 8) | ((a >> 4) << 12)
        else:
            fmt = 0  # 5650
            px = (r >> 3) | ((g >> 2) << 5) | ((b >> 3) << 11)
        tex.alpha[tg] = has_a
        tex_blobs.append((tw, th, fmt, px.astype('<u2').tobytes(), os.path.basename(g2p[tg])))
    # cabecera: n, luego tabla (w,h,fmt,offset,size), luego datos alineados a 16
    with open(os.path.join(out, 'textures.bin'), 'wb') as f:
        f.write(b'BTEX'); f.write(struct.pack('<I', len(tex_blobs)))
        table_pos = f.tell(); f.write(b'\0' * 16 * len(tex_blobs))
        entries = []
        for (w, h, fmt, data, name) in tex_blobs:
            while f.tell() % 16: f.write(b'\0')
            entries.append((w, h, fmt, f.tell(), len(data))); f.write(data)
        end = f.tell(); f.seek(table_pos)
        for (w, h, fmt, off, sz) in entries: f.write(struct.pack('<HHIII', w, h, fmt, off, sz))
    print('texturas:', len(tex_blobs), ' tamano', os.path.getsize(os.path.join(out, 'textures.bin'))//1024, 'KB')

    # --- ordenar quads estaticos por textura; dinamicos aparte
    static = [q for q in quads if q['grp'] == 0xFFFF]
    dyn = [q for q in quads if q['grp'] != 0xFFFF]
    static.sort(key=lambda q: q['tex'])
    # marcar si textura con alpha para pasada de recorte
    tex_alpha = [1 if tex.alpha.get(tg) else 0 for tg in tex.order]

    def pack_quad(q):
        b = b''
        for p in q['p']:
            b += struct.pack('<3f', p[0], p[1], p[2])
        for u, v in q['uv']:
            b += struct.pack('<2f', u, v)
        b += struct.pack('<HHHH', q['tex'] & 0xFFFF, q['texalt'] & 0xFFFF, q['texlock'] & 0xFFFF, q['grp'] & 0xFFFF)
        return b     # 48 + 32 + 8 = 88 bytes
    QSZ = 88

    # --- level.bin
    sec = []
    def add(name, data): sec.append((name, data))
    add('quads', b''.join(pack_quad(q) for q in static))
    add('dquads', b''.join(pack_quad(q) for q in dyn))
    add('segs', b''.join(struct.pack('<6fHH', s['x1'], s['z1'], s['x2'], s['z2'], s['y0'], s['y1'], s['grp'] & 0xFFFF, 0) for s in segs))
    gbytes = b''
    for gr in groups:
        gbytes += struct.pack('<3fIf', gr['pos'][0], gr['pos'][1], gr['pos'][2], gr['kind'], gr['dist'])
    add('groups', gbytes)
    add('pickups', b''.join(struct.pack('<3fHH', p[0][0], p[0][1], p[0][2], p[1], p[2]) for p in pickups))
    add('notebooks', b''.join(struct.pack('<3f', *n) for n in notebooks))
    add('waypoints', b''.join(struct.pack('<3f', *w) for w in waypoints))
    mid = {'BSODAMachine': 1, 'ZestyMachine': 2, 'PayPhone': 3, 'TapePlayer': 4}
    add('machines', b''.join(struct.pack('<3fI', m[1][0], m[1][1], m[1][2], mid[m[0]]) for m in machines))
    npc_order = ['Baldi', 'Principal', 'Playtime', 'FirstPrize', 'Crafters', 'Bully', 'Sweep']
    add('npcs', b''.join(struct.pack('<3f', *npcs.get(n, (0, 0, 0))) for n in npc_order))
    add('triggers', b''.join(struct.pack('<I4fI', t[0], *t[1], t[2] & 0xFFFF) for t in trig_out))
    nav = np.packbits(walk.flatten()).tobytes()
    add('nav', struct.pack('<2f2I', gx0, gz0, gw, gh) + nav)
    add('texalpha', bytes(tex_alpha))
    ex = npcs.get('extra', [0, 0, 0, 0, 0xFFFF])
    add('extra', struct.pack('<4fI', ex[0], ex[1], ex[2], ex[3], ex[4] & 0xFFFF))
    spawn_b = struct.pack('<3f', *(spawn or (5, 4, -5)))
    counts = dict(quads=len(static), dquads=len(dyn), segs=len(segs), groups=len(groups), pickups=len(pickups),
                  notebooks=len(notebooks), waypoints=len(waypoints), machines=len(machines), npcs=len(npc_order),
                  triggers=len(trig_out), tex=len(tex.order))
    names = ['quads', 'dquads', 'segs', 'groups', 'pickups', 'notebooks', 'waypoints', 'machines', 'npcs', 'triggers', 'nav', 'texalpha', 'extra']
    # cabecera: magic, version, spawn(3f), nav-cell(f), counts(12 I), offsets(12 I)
    cnt_list = [counts['quads'], counts['dquads'], counts['segs'], counts['groups'], counts['pickups'], counts['notebooks'],
                counts['waypoints'], counts['machines'], counts['npcs'], counts['triggers'], 0, counts['tex'], 1, 0, 0, 0]
    hdr_size = 4 + 4 + 12 + 4 + 16*4 + 16*4
    offs = []; pos = hdr_size
    secd = dict(sec)
    blob = b''
    for n in names:
        while pos % 16: blob += b'\0'; pos += 1
        offs.append(pos); blob += secd[n]; pos += len(secd[n])
    hdr = b'BLVL' + struct.pack('<I', 1) + spawn_b + struct.pack('<f', NAV_CELL)
    offs += [0] * (16 - len(offs))
    hdr += struct.pack('<16I', *cnt_list) + struct.pack('<16I', *offs)
    assert len(hdr) == hdr_size
    open(os.path.join(out, 'level.bin'), 'wb').write(hdr + blob)
    print('level.bin:', (len(hdr)+len(blob))//1024, 'KB')

    # --- preview cenital
    S_ = 3.0
    W = int((max(xs)-min(xs)+20)*S_); H = int((max(zs)-min(zs)+20)*S_)
    img = Image.new('RGB', (W, H), (20, 20, 20)); d = ImageDraw.Draw(img)
    X = lambda x: (x - (min(xs)-10)) * S_
    Z = lambda z: H - (z - (min(zs)-10)) * S_
    for j in range(gh):
        for i in range(gw):
            if walk[j, i]:
                x = gx0 + i*NAV_CELL; z = gz0 + j*NAV_CELL
                d.rectangle([X(x), Z(z+NAV_CELL), X(x+NAV_CELL), Z(z)], fill=(40, 70, 40))
    for s in segs:
        col = (255, 255, 255) if s['grp'] == 0xFFFF else (255, 80, 80)
        d.line([X(s['x1']), Z(s['z1']), X(s['x2']), Z(s['z2'])], fill=col, width=1)
    for p, t, a in pickups: d.ellipse([X(p[0])-3, Z(p[2])-3, X(p[0])+3, Z(p[2])+3], fill=(255, 220, 0) if a else (120, 120, 0))
    for n in notebooks: d.rectangle([X(n[0])-4, Z(n[2])-4, X(n[0])+4, Z(n[2])+4], fill=(60, 120, 255))
    for w in waypoints: d.ellipse([X(w[0])-2, Z(w[2])-2, X(w[0])+2, Z(w[2])+2], fill=(0, 255, 255))
    for n, p in npcs.items(): d.text((X(p[0]), Z(p[2])), n, fill=(255, 0, 255))
    if spawn: d.ellipse([X(spawn[0])-4, Z(spawn[2])-4, X(spawn[0])+4, Z(spawn[2])+4], fill=(0, 255, 0))
    img.save(os.path.join(out, 'preview.png'))
    return counts

if __name__ == '__main__':
    proj = sys.argv[1] if len(sys.argv) > 1 else '.'
    out = sys.argv[2] if len(sys.argv) > 2 else './out'
    print(main(proj, out))
